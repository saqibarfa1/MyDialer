package com.kohatzmakay.mydialer

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CrmDatabaseTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()

    @Before fun clearDatabase() { context.deleteDatabase("mydialer-crm.db") }
    @After fun closeAndClear() { context.deleteDatabase("mydialer-crm.db") }

    @Test fun savesProfilesNotesTasksAndDeduplicatesCallEvents() {
        CrmDatabase(context).use { db ->
            val profile = CrmProfile("+923001234567", "Ayesha", "Customer", "Contacted", 1, "Call tomorrow", "Acme", "VIP, Sales")
            db.saveProfile(profile)
            assertEquals(profile, db.profile(profile.phone))

            val noteId = db.addNote(profile.phone, "Asked for details")
            assertEquals("Asked for details", db.notes(profile.phone).single().body)
            db.updateNote(noteId, "Sent details")
            assertEquals("Sent details", db.notes(profile.phone).single().body)
            db.setNotePinned(noteId, true)
            assertTrue(db.notes(profile.phone).single().pinned)
            assertEquals(noteId, db.searchNotes("sent detail").single().id)

            val taskId = db.addTask(profile.phone, "Call back", 2_000L)
            assertEquals(profile.phone, db.taskPhone(taskId))
            assertFalse(db.tasks().single().complete)
            db.updateTaskDue(taskId, 2_500L)
            assertEquals(2_500L, db.tasks().single().dueAt)
            db.setTaskComplete(taskId, true)
            assertTrue(db.tasks(includeCompleted = true).single().complete)
            assertTrue(db.tasks().isEmpty())

            assertTrue(db.logCall("event-1", profile.phone, "Outgoing", 3_000L, 42L))
            assertFalse(db.logCall("event-1", profile.phone, "Outgoing", 3_000L, 42L))
            db.setInteractionOutcome("event-1", "Interested")
            assertEquals("Interested", db.interactions(profile.phone).single().outcome)
            db.deleteNote(noteId)
            assertTrue(db.notes(profile.phone).isEmpty())
        }
    }

    @Test fun upgradesExistingProfileSchemaWithoutDroppingData() {
        LegacyV1Database(context).use { helper ->
            val db = helper.writableDatabase
            db.insert("profiles", null, ContentValues().apply { put("phone", "03001234567"); put("name", "Legacy"); put("category", "Buyer"); put("status", "Follow-up"); put("priority", 1); put("headline", "Five marla"); put("company", "") })
        }

        CrmDatabase(context).use { db ->
            val profile = db.profile("03001234567")
            assertNotNull(profile)
            assertEquals("Legacy", profile?.name)
            assertEquals("Five marla", profile?.headline)
            assertEquals("", profile?.tags)
            assertTrue(db.logCall("upgraded-event", "03001234567", "Incoming", 4_000L, 0L))
            assertEquals(CrmDatabase.OPTION_DEFAULTS.getValue("statuses"), db.optionList("statuses"))
            db.setFieldDefinitions(listOf(CrmFieldDefinition("Customer since", true)))
            assertEquals(listOf(CrmFieldDefinition("Customer since", true)), db.fieldDefinitions())
            assertFalse(db.notes("03001234567").single().pinned)
        }
    }

    @Test fun customCategoriesAndStatusesKeepTheUsersOrder() {
        CrmDatabase(context).use { db ->
            assertEquals(CrmDatabase.OPTION_DEFAULTS.getValue("categories"), db.optionList("categories"))
            db.setOptionList("categories", listOf("Family", "Customer", "Family"))
            db.setOptionList("statuses", listOf("Waiting", "Call today", "Completed"))
            db.setStatusColors(mapOf("Waiting" to "Purple", "Call today" to "Orange", "Completed" to "Gray"))
            assertEquals(listOf("Family", "Customer"), db.optionList("categories"))
            assertEquals(listOf("Waiting", "Call today", "Completed"), db.optionList("statuses"))
            assertEquals("Purple", db.statusColors()["Waiting"])
        }
    }

    @Test fun customProfileFieldsPersistRespectVisibilityAndRemoveDeletedValues() {
        CrmDatabase(context).use { db ->
            val phone = "+923001234567"
            val profile = CrmProfile(phone, "Ayesha", "Customer", "New", 0, "", "", customFields = mapOf("Birthday" to "1990-04-12", "Service type" to "Consulting"))
            db.setFieldDefinitions(listOf(CrmFieldDefinition("Birthday", true), CrmFieldDefinition("Service type", false)))
            db.saveProfile(profile)

            assertEquals(profile, db.profile(phone))
            assertEquals(mapOf("Birthday" to "1990-04-12", "Service type" to "Consulting"), db.profiles().single().customFields)

            db.setFieldDefinitions(listOf(CrmFieldDefinition("Birthday", true)))
            assertEquals(mapOf("Birthday" to "1990-04-12"), db.profile(phone)?.customFields)
        }
    }

    @Test fun importsValidatedBackupOnlyOnceAndReturnsFutureReminders() {
        val phone = "+923001234567"
        val dueAt = System.currentTimeMillis() + 60_000L
        val profile = org.json.JSONObject().put("phone", phone).put("name", "Imported").put("category", "Personal").put("status", "New")
            .put("customFields", org.json.JSONObject().put("Account type", "Premium"))
        val note = org.json.JSONObject().put("phone", phone).put("body", "Imported note").put("createdAt", 1_700_000_000_000L).put("pinned", true)
        val task = org.json.JSONObject().put("phone", phone).put("title", "Call back").put("dueAt", dueAt).put("complete", false)
        val interaction = org.json.JSONObject().put("id", "backup-call-1").put("phone", phone).put("direction", "Outgoing").put("occurredAt", 1_700_000_000_000L).put("duration", 30)
        val backup = org.json.JSONObject().put("format", CrmDatabase.BACKUP_FORMAT).put("version", 1).put("backupId", "backup-1")
            .put("profiles", org.json.JSONArray().put(profile)).put("notes", org.json.JSONArray().put(note))
            .put("tasks", org.json.JSONArray().put(task)).put("interactions", org.json.JSONArray().put(interaction))
            .put("categories", org.json.JSONArray().put("Family").put("Customer"))
            .put("statuses", org.json.JSONArray().put("Follow up").put("Completed"))
            .put("statusColors", org.json.JSONObject().put("Follow up", "Orange").put("Completed", "Gray"))
            .put("customFieldDefinitions", org.json.JSONArray().put(org.json.JSONObject().put("name", "Account type").put("visible", true))).toString()

        CrmDatabase(context).use { db ->
            val imported = db.importBackup(backup)
            assertTrue(imported.imported)
            assertEquals(1, imported.tasksToSchedule.size)
            assertEquals("Imported", db.profile(phone)?.name)
            assertEquals(mapOf("Account type" to "Premium"), db.profile(phone)?.customFields)
            assertEquals(listOf(CrmFieldDefinition("Account type", true)), db.fieldDefinitions())
            assertEquals("Imported note", db.notes(phone).single().body)
            assertTrue(db.notes(phone).single().pinned)
            assertEquals("Outgoing", db.interactions(phone).single().direction)
            assertEquals(listOf("Family", "Customer"), db.optionList("categories"))
            assertEquals(listOf("Follow up", "Completed"), db.optionList("statuses"))
            assertEquals("Orange", db.statusColors()["Follow up"])
            assertFalse(db.importBackup(backup).imported)
            assertEquals(1, db.notes(phone).size)
        }
    }

    private class LegacyV1Database(context: Context) : SQLiteOpenHelper(context, "mydialer-crm.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE profiles(phone TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Personal', status TEXT NOT NULL DEFAULT 'New', priority INTEGER NOT NULL DEFAULT 0, headline TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL)")
            db.insert("notes", null, ContentValues().apply { put("phone", "03001234567"); put("body", "Old note"); put("created_at", 3_000L) })
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, title TEXT NOT NULL, due_at INTEGER NOT NULL, complete INTEGER NOT NULL DEFAULT 0)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }
}
