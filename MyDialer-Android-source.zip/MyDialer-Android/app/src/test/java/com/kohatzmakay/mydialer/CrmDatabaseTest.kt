package com.kohatzmakay.mydialer

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CrmDatabaseTest {
    private val context: Context get() = RuntimeEnvironment.getApplication<Application>()

    @Before fun clearDatabase() { context.deleteDatabase("mydialer-crm.db") }
    @After fun closeAndClear() { context.deleteDatabase("mydialer-crm.db") }

    @Test fun savesProfilesNotesTasksAndDeduplicatesCallEvents() {
        CrmDatabase(context).use { db ->
            val profile = CrmProfile("+923001234567", "Ayesha", "Customer", "Contacted", 1, "Call tomorrow", "Acme", "VIP, Sales")
            db.saveProfile(profile)
            assertEquals(profile, db.profile(profile.phone))

            val noteId = db.addNote(profile.phone, "Asked for details")
            assertEquals("Asked for details", db.notes(profile.phone).single().body)
            db.updateNote(noteId, "Sent details")
            assertEquals("Sent details", db.notes(profile.phone).single().body)

            val taskId = db.addTask(profile.phone, "Call back", 2_000L)
            assertEquals(profile.phone, db.taskPhone(taskId))
            assertFalse(db.tasks().single().complete)
            db.setTaskComplete(taskId, true)
            assertTrue(db.tasks(includeCompleted = true).single().complete)
            assertTrue(db.tasks().isEmpty())

            assertTrue(db.logCall("event-1", profile.phone, "Outgoing", 3_000L, 42L))
            assertFalse(db.logCall("event-1", profile.phone, "Outgoing", 3_000L, 42L))
            db.setInteractionOutcome("event-1", "Interested")
            assertEquals("Interested", db.interactions(profile.phone).single().outcome)
            db.deleteNote(noteId)
            assertTrue(db.notes(profile.phone).isEmpty())
        }
    }

    @Test fun upgradesExistingProfileSchemaWithoutDroppingData() {
        LegacyV1Database(context).use { helper ->
            val db = helper.writableDatabase
            db.insert("profiles", null, ContentValues().apply { put("phone", "03001234567"); put("name", "Legacy"); put("category", "Buyer"); put("status", "Follow-up"); put("priority", 1); put("headline", "Five marla"); put("company", "") })
        }

        CrmDatabase(context).use { db ->
            val profile = db.profile("03001234567")
            assertNotNull(profile)
            assertEquals("Legacy", profile?.name)
            assertEquals("Five marla", profile?.headline)
            assertEquals("", profile?.tags)
            assertTrue(db.logCall("upgraded-event", "03001234567", "Incoming", 4_000L, 0L))
        }
    }

    private class LegacyV1Database(context: Context) : SQLiteOpenHelper(context, "mydialer-crm.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE profiles(phone TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Personal', status TEXT NOT NULL DEFAULT 'New', priority INTEGER NOT NULL DEFAULT 0, headline TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, title TEXT NOT NULL, due_at INTEGER NOT NULL, complete INTEGER NOT NULL DEFAULT 0)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    }
}
