package com.kohatzmakay.mydialer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneSearchTest {
    @Test fun normalizesInternationalAndFormattedNumbers() {
        assertEquals("+923001234567", PhoneSearch.normalize("+92 (300) 123-4567"))
        assertEquals("03001234567", PhoneSearch.normalize("0300-123 4567"))
    }

    @Test fun matchesContactNameUsingT9Digits() {
        assertEquals("5646", PhoneSearch.nameToDigits("JOHN"))
        assertTrue(PhoneSearch.matchesT9("John Smith", "+1 555 1234", "5646"))
        assertFalse(PhoneSearch.matchesT9("John Smith", "+1 555 1234", "9999"))
    }

    @Test fun matchesFormattedPhoneByDigits() {
        assertTrue(PhoneSearch.matchesT9("Ayesha", "+92 (300) 123-4567", "300123"))
        assertFalse(PhoneSearch.matchesT9("Ayesha", "+92 (300) 123-4567", ""))
    }
}
