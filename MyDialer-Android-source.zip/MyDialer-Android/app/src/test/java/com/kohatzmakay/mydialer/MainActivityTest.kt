package com.kohatzmakay.mydialer

import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class MainActivityTest {
    private val context get() = RuntimeEnvironment.getApplication()

    @Before fun clearAppState() {
        context.deleteDatabase("mydialer-crm.db")
        context.getSharedPreferences("mydialer_migration", 0).edit().clear().commit()
        context.getSharedPreferences("mydialer_local", 0).edit().clear().commit()
        context.getSharedPreferences("mydialer_settings", 0).edit().clear().commit()
    }

    @After fun clearDatabase() { context.deleteDatabase("mydialer-crm.db") }

    @Test fun primaryNavigationSwitchesTabsAndBackReturnsHome() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        assertNotNull(findByDescription(activity.findViewById(android.R.id.content), "Favorites"))

        buttonByDescription(activity, "CRM").performClick()
        assertEquals("CRM", screenTitle(activity))
        buttonByDescription(activity, "Keypad").performClick()
        assertEquals("Keypad", screenTitle(activity))

        activity.onBackPressed()
        assertEquals("Favorites", screenTitle(activity))
    }

    @Test fun keypadAcceptsDigitsAndLongPressBackspaceClearsThem() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        buttonByDescription(activity, "Keypad").performClick()
        buttonByText(activity, "2\nABC").performClick()
        buttonByText(activity, "3\nDEF").performClick()
        assertTrue(allText(activity.findViewById(android.R.id.content)).contains("23"))

        assertTrue(buttonByText(activity, "⌫").performLongClick())
        assertTrue(allText(activity.findViewById(android.R.id.content)).contains("Enter a number or name"))
    }

    private fun screenTitle(activity: MainActivity): String =
        (activity.findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup).let { root ->
            (root.getChildAt(0) as TextView).text.toString()
        }

    private fun buttonByDescription(activity: MainActivity, description: String): Button =
        findView(activity.findViewById(android.R.id.content)) { it is Button && it.contentDescription == description } as? Button
            ?: error("Button $description not found")

    private fun buttonByText(activity: MainActivity, text: String): Button =
        findView(activity.findViewById(android.R.id.content)) { it is Button && it.text.toString() == text } as? Button
            ?: error("Button $text not found")

    private fun findByDescription(root: View, description: String): View? =
        findView(root) { it.contentDescription == description }

    private fun findView(root: View, predicate: (View) -> Boolean): View? {
        if (predicate(root)) return root
        if (root is ViewGroup) for (index in 0 until root.childCount) findView(root.getChildAt(index), predicate)?.let { return it }
        return null
    }

    private fun allText(root: View): String = buildString {
        fun collect(view: View) {
            if (view is TextView) append(view.text).append('\n')
            if (view is ViewGroup) for (index in 0 until view.childCount) collect(view.getChildAt(index))
        }
        collect(root)
    }
}
