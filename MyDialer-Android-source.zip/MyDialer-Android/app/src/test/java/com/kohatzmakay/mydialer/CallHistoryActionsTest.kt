package com.kohatzmakay.mydialer

import android.content.Intent
import android.provider.CallLog
import android.provider.ContactsContract
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CallHistoryActionsTest {
    @Test fun labelsAvailableCallLogTypesWithoutInventingUnknownTypes() {
        assertEquals("Missed", callTypeLabel(CallLog.Calls.MISSED_TYPE))
        assertEquals("Rejected", callTypeLabel(CallLog.Calls.REJECTED_TYPE))
        assertEquals("Call", callTypeLabel(Int.MIN_VALUE))
    }

    @Test fun contactIntentPassesNameAndNumberToTheSystemEditor() {
        val intent = createContactInsertIntent("Unknown caller", "+923001234567")
        assertEquals(Intent.ACTION_INSERT, intent.action)
        assertEquals(ContactsContract.Contacts.CONTENT_URI, intent.data)
        assertEquals("Unknown caller", intent.getStringExtra(ContactsContract.Intents.Insert.NAME))
        assertEquals("+923001234567", intent.getStringExtra(ContactsContract.Intents.Insert.PHONE))
    }
}
