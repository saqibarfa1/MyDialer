package com.kohatzmakay.mydialer

import android.content.Intent
import android.provider.CallLog
import android.provider.ContactsContract

internal fun callTypeLabel(type: Int): String = when (type) {
    CallLog.Calls.INCOMING_TYPE -> "Incoming"
    CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
    CallLog.Calls.MISSED_TYPE -> "Missed"
    CallLog.Calls.REJECTED_TYPE -> "Rejected"
    CallLog.Calls.BLOCKED_TYPE -> "Blocked"
    CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"
    CallLog.Calls.ANSWERED_EXTERNALLY_TYPE -> "Answered on another device"
    else -> "Call"
}

internal fun createContactInsertIntent(name: String = "", phone: String = ""): Intent =
    Intent(ContactsContract.Intents.Insert.ACTION, ContactsContract.Contacts.CONTENT_URI).apply {
        if (name.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (phone.isNotBlank()) putExtra(ContactsContract.Intents.Insert.PHONE, phone)
    }

internal object CallDurationFormatter {
    fun format(totalSeconds: Long): String {
        val seconds = totalSeconds.coerceAtLeast(0L)
        val minutes = seconds / 60L
        val remainder = seconds % 60L
        return if (minutes >= 60L) "${minutes / 60L}:${(minutes % 60L).toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}"
        else "${minutes}:${remainder.toString().padStart(2, '0')}"
    }
}
