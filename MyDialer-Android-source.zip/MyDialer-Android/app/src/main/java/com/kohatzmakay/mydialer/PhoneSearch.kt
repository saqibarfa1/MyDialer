package com.kohatzmakay.mydialer

object PhoneSearch {
    fun normalize(phone: String): String {
        val normalized = phone.filter { it.isDigit() || it == '+' }
        return if (normalized.startsWith("+")) "+" + normalized.drop(1).filter(Char::isDigit) else normalized.filter(Char::isDigit)
    }

    fun nameToDigits(name: String): String = name.uppercase().mapNotNull(::digitForLetter).joinToString("")

    fun digitForLetter(c: Char): Char? = when (c) {
        in 'A'..'C' -> '2'; in 'D'..'F' -> '3'; in 'G'..'I' -> '4'; in 'J'..'L' -> '5'; in 'M'..'O' -> '6'
        in 'P'..'S' -> '7'; in 'T'..'V' -> '8'; in 'W'..'Z' -> '9'; else -> null
    }

    fun matchesT9(name: String, phone: String, entered: String): Boolean {
        val digits = entered.filter(Char::isDigit)
        if (digits.isBlank()) return false
        return phone.filter(Char::isDigit).contains(digits) || nameToDigits(name).contains(digits)
    }
}
