package com.kohatzmakay.mydialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.app.role.RoleManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

data class PhoneContact(val id: Long, val name: String, val phone: String, val starred: Boolean)
data class RecentCall(val name: String, val phone: String, val type: Int, val date: Long, val duration: Long)

class MainActivity : Activity() {
    private val db by lazy { CrmDatabase(this) }
    private val tabs = listOf("Favorites", "Recents", "Contacts", "Keypad", "CRM")
    private var currentTab = "Favorites"
    private var crmSettings = false
    private var activeProfilePhone: String? = null
    private var keypad = ""
    private var callFilter = -1 // -1 means all call types; Android only defines individual type constants.
    private var pendingBackupJson = ""
    private lateinit var body: LinearLayout
    private lateinit var results: LinearLayout
    private var query = ""
    private val isDark: Boolean get() = when (getSharedPreferences("mydialer_settings", MODE_PRIVATE).getString("appearance", "system")) {
        "dark" -> true
        "light" -> false
        else -> resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
    }
    private val ink: Int get() = if (isDark) 0xFFE8EAED.toInt() else 0xFF202124.toInt()
    private val muted: Int get() = if (isDark) 0xFFBDC1C6.toInt() else 0xFF5F6368.toInt()
    private val surface: Int get() = if (isDark) 0xFF202124.toInt() else 0xFFF8F9FA.toInt()
    private val accent: Int get() = if (isDark) 0xFF8AB4F8.toInt() else 0xFF1A73E8.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        val appearance = getSharedPreferences("mydialer_settings", MODE_PRIVATE).getString("appearance", "system")
        val systemDark = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
        setTheme(if (appearance == "dark" || appearance == "system" && systemDark) R.style.MyDialerDark else R.style.MyDialerLight)
        super.onCreate(savedInstanceState)
        window.statusBarColor = surface
        window.navigationBarColor = surface
        if (!isDark) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        savedInstanceState?.let { state ->
            currentTab = state.getString("tab", currentTab)
            activeProfilePhone = state.getString("profile")
            keypad = state.getString("keypad", keypad)
            crmSettings = state.getBoolean("settings", false)
        }
        migrateLegacyCrmData()
        intent?.getStringExtra(EXTRA_PROFILE_PHONE)?.takeIf { it.isNotBlank() }?.let { activeProfilePhone = it; currentTab = "CRM" }
        intent?.data?.schemeSpecificPart?.takeIf { it.isNotBlank() }?.let { keypad = it }
        render()
        intent?.getStringExtra(EXTRA_POST_CALL_ID)?.let { id -> window.decorView.post { showPostCallFlow(id) } }
        if (intent?.getBooleanExtra(EXTRA_ADD_NOTE, false) == true) activeProfilePhone?.let { phone -> window.decorView.post { addNote(phone) } }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("tab", currentTab); outState.putString("profile", activeProfilePhone); outState.putString("keypad", keypad); outState.putBoolean("settings", crmSettings)
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_PROFILE_PHONE)?.takeIf { it.isNotBlank() }?.let { activeProfilePhone = it; currentTab = "CRM" }
        intent.data?.schemeSpecificPart?.takeIf { it.isNotBlank() }?.let { keypad = it; currentTab = "Keypad" }
        render()
        intent.getStringExtra(EXTRA_POST_CALL_ID)?.let { id -> window.decorView.post { showPostCallFlow(id) } }
        if (intent.getBooleanExtra(EXTRA_ADD_NOTE, false)) activeProfilePhone?.let { phone -> window.decorView.post { addNote(phone) } }
    }

    @Deprecated("Use the system back dispatcher on newer Android versions")
    override fun onBackPressed() {
        when {
            activeProfilePhone != null -> { activeProfilePhone = null; currentTab = "CRM"; render() }
            crmSettings -> { crmSettings = false; currentTab = "CRM"; render() }
            currentTab != "Favorites" -> { currentTab = "Favorites"; render() }
            else -> super.onBackPressed()
        }
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(surface); setPadding(16, 8, 16, 6) }
        root.addView(TextView(this).apply {
            text = when { activeProfilePhone != null -> "Contact profile"; crmSettings -> "Settings"; else -> currentTab }
            textSize = 26f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(4, 10, 4, 16)
        })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildNavigation())
        setContentView(root)
        when {
            activeProfilePhone != null -> renderProfile()
            crmSettings -> renderSettings()
            currentTab == "Keypad" -> renderKeypad()
            currentTab == "Contacts" -> renderContacts()
            currentTab == "Recents" -> renderRecents()
            currentTab == "CRM" -> renderCrm()
            else -> renderFavorites()
        }
    }

    private fun buildNavigation(): View {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 7, 0, 2) }
        tabs.forEach { tab ->
            nav.addView(Button(this).apply {
                text = if (tab == currentTab && activeProfilePhone == null && !crmSettings) "●  $tab" else tab
                textSize = 11f; isAllCaps = false; setTextColor(if (tab == currentTab && activeProfilePhone == null && !crmSettings) accent else muted)
                setPadding(2, 4, 2, 4); contentDescription = tab
                setOnClickListener { currentTab = tab; activeProfilePhone = null; crmSettings = false; query = ""; render() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return nav
    }

    private fun sectionTitle(label: String) = TextView(this).apply { text = label; textSize = 16f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(4, 16, 4, 8) }
    private fun text(label: String, size: Float = 14f, color: Int = ink) = TextView(this).apply { text = label; textSize = size; setTextColor(color); setPadding(4, 5, 4, 5) }
    private fun action(label: String, onClick: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { onClick() } }
    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; views.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
    private fun searchBox(hint: String): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine(true); textSize = 16f; setPadding(14, 4, 14, 4); setBackgroundColor(if (isDark) 0xFF303134.toInt() else 0xFFEFF1F3.toInt())
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty(); if (::results.isInitialized) renderResults() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }
    private fun startList(hint: String) {
        body.addView(searchBox(hint), LinearLayout.LayoutParams(-1, 54))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 4, 0, 12) }
        body.addView(results)
        renderResults()
    }

    private fun renderFavorites() {
        body.addView(text("Your starred people and priority CRM contacts", 14f, muted))
        body.addView(action("＋ Add contact", ::createSystemContact))
        val followUps = db.tasks().filter { it.dueAt <= endOfToday() }.take(3)
        if (followUps.isNotEmpty()) {
            body.addView(sectionTitle("Today's follow-ups"))
            followUps.forEach { task ->
                body.addView(text("${task.title}  ·  ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(task.dueAt))}", 14f))
            }
            body.addView(action("Open all CRM follow-ups", { currentTab = "CRM"; render() }))
        }
        startList("Search favorites")
    }

    private fun renderContacts() {
        body.addView(row(action("＋ New contact", ::createSystemContact), action("Open phone contacts", ::openSystemContacts)))
        startList("Search name or number")
    }

    private fun renderRecents() {
        body.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf("All" to -1, "Missed" to CallLog.Calls.MISSED_TYPE, "Incoming" to CallLog.Calls.INCOMING_TYPE, "Outgoing" to CallLog.Calls.OUTGOING_TYPE).forEach { (label, value) ->
                addView(Button(this@MainActivity).apply { text = label; isAllCaps = false; textSize = 11f; setOnClickListener { callFilter = value; renderResults() } }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        })
        startList("Search call history")
    }

    private fun renderKeypad() {
        body.addView(TextView(this).apply { text = keypad.ifEmpty { "Enter a number or name" }; textSize = 24f; gravity = Gravity.CENTER; setTextColor(ink); setPadding(4, 12, 4, 12) })
        val numberView = body.getChildAt(0) as TextView
        val suggestions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(suggestions)
        val digits = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        digits.chunked(3).forEach { group ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            group.forEach { (digit, letters) ->
                line.addView(Button(this).apply { text = "$digit\n$letters"; textSize = 18f; isAllCaps = false; minHeight = 66; setOnClickListener { keypad += digit; numberView.text = keypad; renderT9(suggestions) } }, LinearLayout.LayoutParams(0, 70, 1f).apply { setMargins(4, 3, 4, 3) })
            }
            body.addView(line)
        }
        val deleteDigit = action("⌫", { if (keypad.isNotEmpty()) keypad = keypad.dropLast(1); numberView.text = keypad.ifEmpty { "Enter a number or name" }; renderT9(suggestions) }).apply {
            setOnLongClickListener { keypad = ""; numberView.text = "Enter a number or name"; renderT9(suggestions); true }
        }
        body.addView(row(
            deleteDigit,
            action("Call", { if (keypad.isNotBlank()) placeCall(keypad) }),
            action("Clear", { keypad = ""; numberView.text = "Enter a number or name"; renderT9(suggestions) })
        ))
        renderT9(suggestions)
    }

    private fun renderT9(target: LinearLayout) {
        target.removeAllViews()
        val entered = keypad.filter { it.isDigit() }
        if (entered.isBlank()) return
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            target.addView(action("Allow Contacts for name search", { ensurePermission(Manifest.permission.READ_CONTACTS, 31) }))
            return
        }
        val people = readContacts().filter { person -> PhoneSearch.matchesT9(person.name, person.phone, entered) }.take(5)
        people.forEach { person -> target.addView(action("${person.name}  ·  ${person.phone}", { keypad = person.phone; render() })) }
    }

    private fun renderCrm() {
        body.addView(text("Notes, relationship details and follow-up tasks are stored locally on this phone.", 14f, muted))
        body.addView(row(action("＋ Add CRM profile", ::chooseContactForCrm), action("Settings", { crmSettings = true; render() })))
        body.addView(sectionTitle("Follow-ups"))
        val openTasks = db.tasks()
        if (openTasks.isEmpty()) body.addView(text("No follow-ups scheduled", 14f, muted))
        openTasks.forEach { task -> body.addView(taskRow(task)) }
        val completedTasks = db.tasks(includeCompleted = true).filter { it.complete }.take(20)
        if (completedTasks.isNotEmpty()) {
            body.addView(sectionTitle("Recently completed"))
            completedTasks.forEach { task -> body.addView(taskRow(task)) }
        }
        body.addView(sectionTitle("Profiles"))
        startList("Search CRM")
    }

    private fun taskRow(task: CrmTask): View {
        val phone = db.taskPhone(task.id)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        layout.addView(text(task.title, 15f))
        val dueState = when { task.complete -> "Completed"; task.dueAt < System.currentTimeMillis() -> "Overdue"; task.dueAt < endOfToday() -> "Today"; else -> "Upcoming" }
        layout.addView(text("$dueState  ·  ${DateFormat.getDateTimeInstance().format(Date(task.dueAt))}${if (phone.isNotBlank()) "  ·  $phone" else ""}", 12f, muted))
        if (task.complete) layout.addView(action("Reopen", { db.setTaskComplete(task.id, false); ReminderReceiver.schedule(this, task.copy(complete = false)); render() }))
        else layout.addView(row(
                action("Done", { db.setTaskComplete(task.id, true); ReminderReceiver.cancel(this, task.id); render() }),
                action("+1 day", { val due = task.dueAt + 24L * 60L * 60L * 1000L; db.updateTaskDue(task.id, due); ReminderReceiver.schedule(this, task.copy(dueAt = due)); render() }),
                action("Reschedule", { rescheduleTask(task) })
            ))
        return layout
    }

    private fun endOfToday(): Long = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis

    private fun rescheduleTask(task: CrmTask) {
        val initial = Calendar.getInstance().apply { timeInMillis = task.dueAt }
        DatePickerDialog(this, { _, year, month, day ->
            TimePickerDialog(this, { _, hour, minute ->
                val due = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                db.updateTaskDue(task.id, due)
                ReminderReceiver.schedule(this, task.copy(dueAt = due))
                render()
            }, initial.get(Calendar.HOUR_OF_DAY), initial.get(Calendar.MINUTE), false).show()
        }, initial.get(Calendar.YEAR), initial.get(Calendar.MONTH), initial.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun renderSettings() {
        body.addView(action("‹ Back to CRM", { crmSettings = false; render() }))
        body.addView(sectionTitle("Calling"))
        body.addView(text("Default phone app: ${if (isDefaultDialer()) "MyDialer" else "Another phone app"}", 14f, muted))
        body.addView(action("Set MyDialer as default phone app", ::requestDialerRole))
        body.addView(text("READ_PHONE_STATE is only used here to list phone accounts for outgoing SIM selection.", 12f, muted))
        body.addView(action("Choose outgoing SIM/account", ::chooseSim))
        body.addView(sectionTitle("Permissions and privacy"))
        body.addView(text("Contacts and call history are read only when Android permissions allow. CRM profiles, notes and tasks stay in this app's local database.", 14f, muted))
        body.addView(action("Open Android app permissions", { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }))
        body.addView(sectionTitle("App appearance"))
        val appearance = getSharedPreferences("mydialer_settings", MODE_PRIVATE).getString("appearance", "system") ?: "system"
        body.addView(text("Appearance: ${appearance.replaceFirstChar { it.uppercase() }}", 14f, muted))
        body.addView(action("Choose appearance", {
            val values = arrayOf("System default", "Light", "Dark")
            AlertDialog.Builder(this).setTitle("Appearance").setItems(values) { _, which ->
                val value = when (which) { 1 -> "light"; 2 -> "dark"; else -> "system" }
                getSharedPreferences("mydialer_settings", MODE_PRIVATE).edit().putString("appearance", value).apply()
                recreate()
            }.show()
        }))
        body.addView(sectionTitle("CRM setup"))
        body.addView(text("Customize the suggestions shown in CRM profiles. Put each item on its own line; the line order is the menu order. You can still type a one-off value in a profile.", 13f, muted))
        body.addView(action("Manage contact categories", { editOptionList("categories", "Contact categories") }))
        body.addView(action("Manage contact statuses", { editOptionList("statuses", "Contact statuses") }))
        body.addView(action("Export local CRM backup", ::exportBackup))
        body.addView(action("Import local CRM backup", ::chooseBackupToImport))
        body.addView(action("Delete local CRM data", ::confirmDeleteLocalData))
        body.addView(sectionTitle("Platform limits"))
        body.addView(text("Call-log access and call controls depend on Android version, permissions, device support and the default dialer role. Reminders are scheduled as inexact alarms to respect battery restrictions.", 13f, muted))
    }

    private fun editOptionList(name: String, title: String) {
        val input = EditText(this).apply {
            hint = "One item per line; order from top to bottom"
            minLines = 7
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(db.optionList(name).joinToString("\n"))
        }
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply {
            setPadding(20, 0, 20, 0); addView(input)
        }).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val values = input.text.toString().lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
                runCatching { db.setOptionList(name, values) }
                    .onSuccess { dialog.dismiss(); toast("$title saved"); render() }
                    .onFailure { toast(it.message ?: "Could not save this list") }
            }
        }
        dialog.show()
    }

    private fun renderProfile() {
        val phone = activeProfilePhone ?: return
        val name = contactByPhone(phone)?.name ?: db.profile(phone)?.name.orEmpty().ifBlank { phone }
        var profile = db.profile(phone) ?: CrmProfile(phone, name, "Personal", "New", 0, "", "").also(db::saveProfile)
        body.addView(text(name, 24f)); body.addView(text(phone, 14f, muted))
        body.addView(row(action("Call", { placeCall(phone) }), action("Message", { openMessage(phone) }), action("Edit contact", { editSystemContact(phone) })))
        body.addView(row(action("Edit CRM details", { editProfile(profile) }), action(if (profile.priority != 0) "★ Priority" else "☆ Set priority", {
            profile = profile.copy(priority = if (profile.priority != 0) 0 else 1); db.saveProfile(profile); render()
        })))
        if (profile.headline.isNotBlank()) body.addView(text(profile.headline, 16f, accent))
        body.addView(text("${profile.category}  ·  ${profile.status}${if (profile.company.isNotBlank()) "  ·  ${profile.company}" else ""}", 14f, muted))
        if (profile.tags.isNotBlank()) body.addView(text("Tags: ${profile.tags}", 13f, muted))
        body.addView(row(action("＋ Note", { addNote(phone) }), action("＋ Reminder", { addTask(phone) })))
        body.addView(sectionTitle("Notes"))
        val notes = db.notes(phone)
        if (notes.isEmpty()) body.addView(text("No notes yet", 14f, muted))
        notes.forEach { note ->
            val noteText = text(note.body, 14f)
            noteText.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("Note")
                    .setItems(arrayOf("Edit", "Delete")) { _, choice ->
                        if (choice == 0) editNote(note) else AlertDialog.Builder(this).setMessage("Delete this note?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> db.deleteNote(note.id); render() }.show()
                    }.show(); true
            }
            body.addView(noteText); body.addView(text(DateFormat.getDateTimeInstance().format(Date(note.createdAt)), 11f, muted))
        }
        body.addView(sectionTitle("Open tasks"))
        val tasks = db.tasks().filter { db.taskPhone(it.id) == phone }
        if (tasks.isEmpty()) body.addView(text("No follow-ups scheduled", 14f, muted))
        tasks.forEach { body.addView(taskRow(it)) }
        body.addView(sectionTitle("Call interactions"))
        val interactions = db.interactions(phone)
        if (interactions.isEmpty()) body.addView(text("No in-app call interactions recorded", 14f, muted))
        interactions.forEach { interaction ->
            body.addView(text("${interaction.direction}  ·  ${DateFormat.getDateTimeInstance().format(Date(interaction.occurredAt))}  ·  ${interaction.duration}s", 13f))
            if (interaction.outcome.isNotBlank()) body.addView(text("Outcome: ${interaction.outcome}", 12f, muted))
        }
    }

    private fun editProfile(p: CrmProfile) {
        val fields = listOf(choiceField("Relationship/category", p.category, "categories"),
            choiceField("Status", p.status, "statuses"),
            EditText(this).apply { hint = "Headline"; setText(p.headline) }, EditText(this).apply { hint = "Company"; setText(p.company) },
            EditText(this).apply { hint = "Tags, separated by commas"; setText(p.tags) })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 0, 16, 0); fields.forEach { addView(it) } }
        AlertDialog.Builder(this).setTitle("CRM profile").setView(ScrollView(this).apply { addView(box) }).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> db.saveProfile(p.copy(category = fields[0].text.toString().trim().ifBlank { "Personal" }, status = fields[1].text.toString().trim().ifBlank { "New" }, headline = fields[2].text.toString().trim(), company = fields[3].text.toString().trim(), tags = fields[4].text.toString().trim())); render() }.show()
    }

    private fun choiceField(label: String, value: String, optionName: String) = AutoCompleteTextView(this).apply {
        hint = label
        setText(value, false)
        threshold = 1
        setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, db.optionList(optionName)))
    }

    private fun addNote(phone: String) {
        val input = EditText(this).apply { hint = "Write a note"; minLines = 3; gravity = Gravity.TOP }
        AlertDialog.Builder(this).setTitle("New note").setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> input.text.toString().trim().takeIf { it.isNotBlank() }?.let { db.addNote(phone, it); render() } }.show()
    }

    private fun editNote(note: CrmNote) {
        val input = EditText(this).apply { setText(note.body); minLines = 3; gravity = Gravity.TOP }
        AlertDialog.Builder(this).setTitle("Edit note").setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> input.text.toString().trim().takeIf { it.isNotBlank() }?.let { db.updateNote(note.id, it); render() } }.show()
    }

    private fun showPostCallFlow(id: String) {
        val interaction = db.interaction(id) ?: return
        val outcomes = arrayOf("Interested", "Follow-up required", "Meeting scheduled", "Information shared", "No answer", "Not interested", "Completed")
        AlertDialog.Builder(this).setTitle("Call complete · ${interaction.direction}")
            .setItems(outcomes) { _, which ->
                val outcome = outcomes[which]
                db.setInteractionOutcome(id, outcome)
                val current = db.profile(interaction.phone) ?: CrmProfile(interaction.phone, contactByPhone(interaction.phone)?.name.orEmpty(), "Personal", "New", 0, "", "")
                db.saveProfile(current.copy(status = outcome))
                render()
                AlertDialog.Builder(this).setTitle("Next step?")
                    .setItems(arrayOf("Add a note", "Set a follow-up", "Skip")) { _, next -> when (next) {
                        0 -> addNote(interaction.phone)
                        1 -> addTask(interaction.phone)
                    } }.show()
            }
            .setNegativeButton("Skip", null).show()
    }

    private fun addTask(phone: String) {
        val title = EditText(this).apply { hint = "Follow-up task"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("New reminder").setView(title).setNegativeButton("Cancel", null)
            .setPositiveButton("Choose date and time") { _, _ ->
                val now = Calendar.getInstance()
                DatePickerDialog(this, { _, year, month, day ->
                    TimePickerDialog(this, { _, hour, minute ->
                        val due = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                        val taskTitle = title.text.toString().trim().ifBlank { "Follow up with ${contactByPhone(phone)?.name ?: phone}" }
                        val id = db.addTask(phone, taskTitle, due)
                        ReminderReceiver.schedule(this, CrmTask(id, taskTitle, due, false))
                        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 33)
                        render()
                    }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
                }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
            }.show()
    }

    private fun chooseContactForCrm() {
        if (!ensurePermission(Manifest.permission.READ_CONTACTS, 31)) return
        val people = readContacts()
        if (people.isEmpty()) { toast("No phone contacts found"); return }
        AlertDialog.Builder(this).setTitle("Choose a contact").setItems(people.take(100).map { "${it.name}  ·  ${it.phone}" }.toTypedArray()) { _, which -> openProfile(people[which].phone) }.show()
    }

    private fun renderResults() {
        if (!::results.isInitialized) return
        results.removeAllViews()
        when {
            activeProfilePhone != null -> return
            currentTab == "CRM" && !crmSettings -> {
                val term = query.trim().lowercase()
                val profiles = db.profiles().filter { profile ->
                    term.isBlank() || listOf(profile.name, profile.phone, profile.category, profile.status, profile.headline, profile.company, profile.tags).any { it.lowercase().contains(term) } ||
                        db.notes(profile.phone).any { it.body.contains(term, true) } || db.tasks().any { it.title.contains(term, true) && db.taskPhone(it.id) == profile.phone }
                }
                profiles.forEach { p -> results.addView(action("${if (p.priority != 0) "★ " else ""}${p.name.ifBlank { p.phone }}  ·  ${p.category}  ·  ${p.status}", { openProfile(p.phone) })) }
                if (profiles.isEmpty()) results.addView(text("No CRM profiles yet. Add one from Contacts.", 14f, muted))
            }
            currentTab == "Recents" -> renderRecentRows()
            else -> renderContactRows()
        }
    }

    private fun renderContactRows() {
        val contacts = readContacts()
        val crmProfiles = db.profiles()
        val all = if (currentTab == "Favorites") contacts + crmProfiles.filter { it.priority > 0 }.mapNotNull { profile ->
            contacts.firstOrNull { normalizePhone(it.phone) == normalizePhone(profile.phone) }
                ?: PhoneContact(-1L, profile.name, profile.phone, false)
        } else contacts
        val term = query.trim().lowercase()
        val crmByPhone = crmProfiles.associateBy { normalizePhone(it.phone) }
        val filtered = all.filter { person ->
            val match = term.isBlank() || person.name.lowercase().contains(term) || person.phone.contains(term)
            val favourite = currentTab != "Favorites" || person.starred || crmByPhone[normalizePhone(person.phone)]?.priority != null && crmByPhone[normalizePhone(person.phone)]?.priority != 0
            match && favourite
        }.distinctBy { normalizePhone(it.phone) }.take(200)
        if (filtered.isEmpty()) {
            results.addView(text(if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) "No contacts match. Add a phone contact to begin." else "Allow Contacts access to show your address book.", 14f, muted))
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) results.addView(action("Allow contacts", { ensurePermission(Manifest.permission.READ_CONTACTS, 31) }))
        }
        filtered.forEach { person ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 7, 4, 7) }
            box.addView(text("${if (person.starred) "★ " else ""}${person.name.ifBlank { person.phone }}", 16f))
            box.addView(text(person.phone, 13f, muted))
            box.addView(row(action("Call", { placeCall(person.phone) }), action("CRM", { openProfile(person.phone, person.name) }), action("Message", { openMessage(person.phone) })))
            results.addView(box); results.addView(View(this).apply { setBackgroundColor(0xFFE5E7EB.toInt()) }, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun renderRecentRows() {
        if (!ensurePermission(Manifest.permission.READ_CALL_LOG, 32)) {
            results.addView(text("Allow call history access to see recent calls.", 14f, muted))
            results.addView(action("Allow call history", { ensurePermission(Manifest.permission.READ_CALL_LOG, 32) }))
            return
        }
        val calls = readCallLog().filter { query.isBlank() || it.name.contains(query, true) || it.phone.contains(query, true) }
        if (calls.isEmpty()) results.addView(text("No calls in this filter", 14f, muted))
        calls.forEach { call ->
            val label = when (call.type) { CallLog.Calls.MISSED_TYPE -> "Missed"; CallLog.Calls.INCOMING_TYPE -> "Incoming"; CallLog.Calls.OUTGOING_TYPE -> "Outgoing"; CallLog.Calls.REJECTED_TYPE -> "Rejected"; else -> "Call" }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 7, 4, 7) }
            box.addView(text("${call.name.ifBlank { call.phone }}  ·  $label", 16f))
            box.addView(text("${DateFormat.getDateTimeInstance().format(Date(call.date))}  ·  ${call.duration}s", 12f, muted))
            box.addView(row(action("Call back", { placeCall(call.phone) }), action("CRM", { openProfile(call.phone, call.name) }), action("Message", { openMessage(call.phone) })))
            results.addView(box)
        }
    }

    private fun readContacts(): List<PhoneContact> {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.Contacts.STARRED)
        return runCatching { contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE")?.use { c ->
            buildList { while (c.moveToNext() && size < 500) add(PhoneContact(c.getLong(0), c.getString(1).orEmpty(), c.getString(2).orEmpty(), c.getInt(3) != 0)) }
        } ?: emptyList() }.getOrDefault(emptyList())
    }

    private fun readCallLog(): List<RecentCall> {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val projection = arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION)
        val uri = CallLog.Calls.CONTENT_URI.buildUpon().appendQueryParameter(CallLog.Calls.LIMIT_PARAM_KEY, "300").build()
        val selection = if (callFilter < 0) null else "${CallLog.Calls.TYPE}=?"
        val selectionArgs = if (callFilter < 0) null else arrayOf(callFilter.toString())
        return runCatching { contentResolver.query(uri, projection, selection, selectionArgs, "${CallLog.Calls.DATE} DESC")?.use { c ->
            buildList { while (c.moveToNext() && size < 200) add(RecentCall(c.getString(0).orEmpty(), c.getString(1).orEmpty(), c.getInt(2), c.getLong(3), c.getLong(4))) }
        } ?: emptyList() }.getOrDefault(emptyList())
    }

    private fun openProfile(phone: String, name: String = "") {
        val normalized = normalizePhone(phone).ifBlank { phone }
        val existing = db.profile(normalized)
        db.saveProfile(existing ?: CrmProfile(normalized, name.ifBlank { contactByPhone(phone)?.name.orEmpty() }, "Personal", "New", 0, "", ""))
        activeProfilePhone = normalized; crmSettings = false; currentTab = "CRM"; render()
    }

    private fun contactByPhone(phone: String): PhoneContact? = readContacts().firstOrNull { normalizePhone(it.phone) == normalizePhone(phone) }
    private fun normalizePhone(phone: String) = PhoneSearch.normalize(phone)

    private fun createSystemContact() {
        startActivity(Intent(Intent.ACTION_INSERT).setType(ContactsContract.Contacts.CONTENT_TYPE))
    }

    private fun editSystemContact(phone: String) {
        val person = contactByPhone(phone)
        if (person == null) { createSystemContact(); return }
        startActivity(Intent(Intent.ACTION_EDIT, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, person.id)))
    }

    private fun openSystemContacts() = runCatching { startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)) }.onFailure { toast("Contacts app unavailable") }
    private fun openMessage(phone: String) = runCatching { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}"))) }.onFailure { toast("Messaging app unavailable") }

    private fun placeCall(number: String) {
        if (number.isBlank()) return
        val uri = Uri.fromParts("tel", number, null)
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            val selectedId = getSharedPreferences("mydialer_settings", MODE_PRIVATE).getString("outgoing_account_id", null)
            val account = if (selectedId != null && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                runCatching { getSystemService(TelecomManager::class.java).callCapablePhoneAccounts.firstOrNull { it.id == selectedId } }.getOrNull()
            } else null
            runCatching {
                if (account != null) getSystemService(TelecomManager::class.java).placeCall(uri, Bundle().apply { putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account) })
                else startActivity(Intent(Intent.ACTION_CALL, uri))
            }.onFailure { startActivity(Intent(Intent.ACTION_DIAL, uri)) }
        } else startActivity(Intent(Intent.ACTION_DIAL, uri))
    }

    private fun chooseSim() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 34)
            return
        }
        showSimPicker()
    }

    private fun showSimPicker() {
        val telecom = getSystemService(TelecomManager::class.java)
        val accounts = runCatching { telecom.callCapablePhoneAccounts }.getOrDefault(emptyList())
        if (accounts.isEmpty()) { toast("No call-capable SIM accounts are available on this device."); return }
        val labels = accounts.mapIndexed { index, _ -> "Phone account ${index + 1}" }.toTypedArray()
        val selectedId = getSharedPreferences("mydialer_settings", MODE_PRIVATE).getString("outgoing_account_id", null)
        val selectedIndex = accounts.indexOfFirst { it.id == selectedId }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Preferred outgoing SIM/account")
            .setSingleChoiceItems(labels, selectedIndex) { dialog, which ->
                getSharedPreferences("mydialer_settings", MODE_PRIVATE).edit().putString("outgoing_account_id", accounts[which].id).apply()
                dialog.dismiss(); toast("Phone account ${which + 1} selected for outgoing calls")
            }
            .setNeutralButton("Use Android's choice") { _, _ -> getSharedPreferences("mydialer_settings", MODE_PRIVATE).edit().remove("outgoing_account_id").apply() }
            .setNegativeButton("Close", null).show()
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roles = getSystemService(RoleManager::class.java)
            if (roles.isRoleAvailable(RoleManager.ROLE_DIALER)) startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_DIALER), 200)
            else toast("This Android device does not offer the dialer role")
        } else {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName), 200)
        }
    }

    private fun isDefaultDialer(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
    else (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == packageName

    private fun ensurePermission(permission: String, requestCode: Int): Boolean {
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return true
        requestPermissions(arrayOf(permission), requestCode)
        return false
    }

    @Deprecated("Android permission result API")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            render()
            if (requestCode == 34) showSimPicker()
            if (currentTab == "Keypad") renderT9(body.getChildAt(1) as? LinearLayout ?: return)
        }
        else toast("Permission not granted. You can continue using other parts of MyDialer.")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun exportBackup() {
        val profileData = org.json.JSONArray()
        val noteData = org.json.JSONArray()
        val taskData = org.json.JSONArray()
        val interactionData = org.json.JSONArray()
        db.profiles().forEach { p ->
            profileData.put(org.json.JSONObject().put("phone", p.phone).put("name", p.name).put("category", p.category).put("status", p.status)
                .put("priority", p.priority).put("headline", p.headline).put("company", p.company).put("tags", p.tags))
            db.notes(p.phone).forEach { note -> noteData.put(org.json.JSONObject().put("phone", p.phone).put("body", note.body).put("createdAt", note.createdAt)) }
            db.interactions(p.phone).forEach { event -> interactionData.put(org.json.JSONObject().put("id", event.id).put("phone", p.phone).put("direction", event.direction)
                .put("occurredAt", event.occurredAt).put("duration", event.duration).put("outcome", event.outcome)) }
        }
        db.tasks(includeCompleted = true).forEach { task -> taskData.put(org.json.JSONObject().put("phone", db.taskPhone(task.id)).put("title", task.title).put("dueAt", task.dueAt).put("complete", task.complete)) }
        pendingBackupJson = org.json.JSONObject().put("format", "MyDialer local CRM").put("version", 1).put("exportedAt", System.currentTimeMillis())
            .put("backupId", java.util.UUID.randomUUID().toString())
            .put("profiles", profileData).put("notes", noteData).put("tasks", taskData).put("interactions", interactionData)
            .put("categories", org.json.JSONArray(db.optionList("categories"))).put("statuses", org.json.JSONArray(db.optionList("statuses"))).toString(2)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, "MyDialer-backup.json")
        runCatching { startActivityForResult(intent, 301) }.onFailure { toast("No file app available to save the backup") }
    }

    private fun chooseBackupToImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
        runCatching { startActivityForResult(intent, 302) }.onFailure { toast("No file app available to open the backup") }
    }

    private fun readLimited(input: java.io.InputStream, maxBytes: Int): String {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            require(output.size() + count <= maxBytes) { "Backup file is larger than 5 MB" }
            output.write(buffer, 0, count)
        }
        return output.toString(Charsets.UTF_8.name())
    }

    private fun confirmImportBackup(json: String) {
        AlertDialog.Builder(this).setTitle("Import CRM backup?")
            .setMessage("The backup will merge with CRM data on this phone. Device contacts and Android call history will not be changed. The same backup file will only be imported once.")
            .setNegativeButton("Cancel", null).setPositiveButton("Import") { _, _ ->
                runCatching { db.importBackup(json) }.onSuccess { result ->
                    if (!result.imported) toast("This backup was already imported")
                    else {
                        result.tasksToSchedule.forEach { ReminderReceiver.schedule(this, it) }
                        toast("CRM backup imported")
                    }
                    render()
                }.onFailure { toast("Backup could not be imported. Check that it is a valid MyDialer backup.") }
            }.show()
    }

    private fun confirmDeleteLocalData() {
        AlertDialog.Builder(this).setTitle("Delete local CRM data?")
            .setMessage("This permanently removes CRM profiles, notes, interactions and follow-up tasks from this phone. Device contacts and Android call history are not deleted.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                db.tasks(includeCompleted = true).forEach { ReminderReceiver.cancel(this, it.id) }
                db.close(); deleteDatabase("mydialer-crm.db")
                activeProfilePhone = null; toast("Local CRM data deleted"); render()
            }.show()
    }

    @Deprecated("Android document picker result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 301 && resultCode == RESULT_OK && data?.data != null) {
            runCatching { contentResolver.openOutputStream(data.data!!)?.use { it.write(pendingBackupJson.toByteArray(Charsets.UTF_8)) } ?: error("Could not open destination") }
                .onSuccess { toast("CRM backup saved") }.onFailure { toast("Backup could not be saved") }
        } else if (requestCode == 302 && resultCode == RESULT_OK && data?.data != null) {
            runCatching { contentResolver.openInputStream(data.data!!)?.use { readLimited(it, 5 * 1024 * 1024) } ?: error("Could not open backup") }
                .onSuccess { confirmImportBackup(it) }.onFailure { toast("Backup file could not be read") }
        }
    }

    private fun migrateLegacyCrmData() {
        val marker = getSharedPreferences("mydialer_migration", MODE_PRIVATE)
        if (marker.getBoolean("legacy_json_imported", false)) return
        val legacy = getSharedPreferences("mydialer_local", MODE_PRIVATE).getString("contacts", "[]").orEmpty()
        runCatching {
            val array = org.json.JSONArray(legacy)
            for (index in 0 until array.length()) {
                val old = array.optJSONObject(index) ?: continue
                val phone = PhoneSearch.normalize(old.optString("phone"))
                if (phone.isBlank()) continue
                val name = old.optString("name")
                val kind = old.optString("kind", "Personal").ifBlank { "Personal" }
                val headline = old.optString("need").ifBlank { "" }
                val status = old.optString("status", "New").ifBlank { "New" }
                db.saveProfile(CrmProfile(phone, name, kind, status, if (old.optBoolean("favorite")) 1 else 0, headline, ""))
                val context = listOf(
                    "Area: ${old.optString("area")}", "Budget: ${old.optString("budget")}", "Need: ${old.optString("need")}", "Follow-up: ${old.optString("reminder")}"
                ).filterNot { it.endsWith(": ") }.joinToString("\n")
                val notes = old.optString("notes")
                val preserved = listOf(context, notes).filter { it.isNotBlank() }.joinToString("\n\n")
                if (preserved.isNotBlank()) db.addNote(phone, "Migrated from previous MyDialer version\n$preserved")
            }
        }
        marker.edit().putBoolean("legacy_json_imported", true).apply()
    }

    companion object {
        const val EXTRA_PROFILE_PHONE = "profile_phone"
        const val EXTRA_POST_CALL_ID = "post_call_id"
        const val EXTRA_ADD_NOTE = "add_note"
    }
}
