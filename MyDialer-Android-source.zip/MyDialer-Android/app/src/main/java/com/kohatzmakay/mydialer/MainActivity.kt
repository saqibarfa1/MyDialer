package com.kohatzmakay.mydialer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

private const val STORE = "mydialer_local"
private const val DATA = "contacts"

data class Lead(val id: Long, var name: String, var phone: String, var kind: String, var area: String, var budget: String, var need: String, var status: String, var reminder: String, var notes: String, var favorite: Boolean)

class MainActivity : Activity() {
    private val leads = mutableListOf<Lead>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var summary: TextView
    private val navy = 0xFF10233F.toInt()
    private val gold = 0xFFD8AD58.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        requestPermissionsIfNeeded()
        maybeRequestDialerRole()
        buildUi()
    }
    private fun requestPermissionsIfNeeded() {
        val perms = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
    }
    private fun maybeRequestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 200)
        } else {
            val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (tm.defaultDialerPackage != packageName) {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName), 200)
            }
        }
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,12); setBackgroundColor(0xFFF3F5F8.toInt()) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(navy) }
        header.addView(TextView(this).apply { text="MyDialer"; textSize=25f; setTextColor(-1); setTypeface(null,1) })
        header.addView(TextView(this).apply { text="Offline contacts · Property CRM · Follow-ups"; textSize=13f; setTextColor(gold) })
        root.addView(header, LinearLayout.LayoutParams(-1,-2))
        summary = TextView(this).apply { textSize=14f; setPadding(4,14,4,10); setTextColor(navy) }
        root.addView(summary)
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val add = Button(this).apply { text="＋ Add contact"; setOnClickListener { editLead(null) } }
        val backup = Button(this).apply { text="Backup"; setOnClickListener { exportBackup() } }
        row.addView(add, LinearLayout.LayoutParams(0,-2,1f)); row.addView(backup, LinearLayout.LayoutParams(0,-2,1f)); root.addView(row)
        search = EditText(this).apply { hint="Search name, phone, area, budget"; singleLine=true }
        root.addView(search)
        search.addTextChangedListener(SimpleWatcher { renderList() })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,8,0,8) }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(TextView(this).apply { text="Saved on this phone only. Keep exported backups. Native call UI requires setting MyDialer as default phone app."; textSize=11f; setTextColor(0xFF6B7280.toInt()); setPadding(3,8,3,2) })
        setContentView(root); renderList()
        intent?.data?.schemeSpecificPart?.let { number -> if (number.isNotBlank()) editLead(Lead(System.currentTimeMillis(),"",number,"Buyer","","","Plot","New lead","","",false)) }
    }
    private fun renderList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q=search.text.toString().trim().lowercase()
        val shown=leads.filter { listOf(it.name,it.phone,it.area,it.budget,it.need,it.notes,it.kind,it.status).any { s -> s.lowercase().contains(q) } }.sortedWith(compareByDescending<Lead>{it.favorite}.thenByDescending{it.id})
        summary.text="${leads.size} contacts   ·   ${leads.count { it.status=="Follow-up" }} follow-ups   ·   ${leads.count { it.favorite }} favorites"
        if (shown.isEmpty()) { list.addView(TextView(this).apply { text="No contacts yet. Tap Add contact to start."; textSize=16f; gravity=Gravity.CENTER; setPadding(12,40,12,40) }); return }
        shown.forEach { lead ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,12); setBackgroundColor(-1) }
            card.addView(TextView(this).apply { text=(if(lead.favorite) "★ " else "")+lead.name; textSize=18f; setTextColor(navy); setTypeface(null,1) })
            card.addView(TextView(this).apply { text=lead.phone+" · "+lead.kind+" · "+lead.need; setTextColor(0xFF505A6A.toInt()) })
            card.addView(TextView(this).apply { text=listOf(lead.area,lead.budget,lead.status,lead.reminder).filter{it.isNotBlank()}.joinToString("  ·  "); setTextColor(0xFF6B7280.toInt()); textSize=12f })
            if (lead.notes.isNotBlank()) card.addView(TextView(this).apply { text=lead.notes; setPadding(0,6,0,0) })
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply { text="Call"; setOnClickListener { try { startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:"+Uri.encode(lead.phone)))) } catch (_:Exception) { startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(lead.phone)))) } } })
            actions.addView(Button(this).apply { text="WhatsApp"; setOnClickListener { val n=lead.phone.filter{it.isDigit()}; val intl=if(n.startsWith("0")) "92"+n.drop(1) else n; try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$intl"))) } catch (_:Exception) {} } })
            actions.addView(Button(this).apply { text="Edit"; setOnClickListener { editLead(lead) } })
            actions.addView(Button(this).apply { text="Note"; setOnClickListener { quickNote(lead) } })
            card.addView(actions)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10); list.addView(card,lp)
        }
    }
    private fun editLead(existing: Lead?) {
        val fields= mutableListOf<EditText>()
        val labels=listOf("Name","Phone","Type: Buyer/Seller/Investor/Tenant","Area","Budget / demand","Need: Plot/House/Commercial/Land","Status","Follow-up date/time","Notes")
        val initial=existing?.let { listOf(it.name,it.phone,it.kind,it.area,it.budget,it.need,it.status,it.reminder,it.notes) } ?: listOf("","","Buyer","","","Plot","New lead","","")
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,0,20,0) }
        labels.forEachIndexed { i,label ->
            val e=EditText(this).apply { hint=label; setText(initial[i]); if(i==1) inputType=3; if(i==8) minLines=2 }
            fields.add(e); box.addView(e,LinearLayout.LayoutParams(-1,-2))
        }
        val fav=CheckBox(this).apply { text="Favorite"; isChecked=existing?.favorite ?: false }; box.addView(fav)
        val scroll=ScrollView(this); scroll.addView(box)
        AlertDialog.Builder(this).setTitle(if(existing==null) "Add contact" else "Edit contact").setView(scroll)
            .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ ->
                val v=fields.map{it.text.toString().trim()}
                if(v[0].isBlank()||v[1].isBlank()){ Toast.makeText(this,"Name and phone are required",Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val item=Lead(existing?.id ?: System.currentTimeMillis(),v[0],v[1],v[2].ifBlank{"Buyer"},v[3],v[4],v[5].ifBlank{"Plot"},v[6].ifBlank{"New lead"},v[7],v[8],fav.isChecked)
                if(existing==null) leads.add(0,item) else { val ix=leads.indexOfFirst{it.id==existing.id}; if(ix>=0) leads[ix]=item }
                persist(); renderList()
            }.show()
    }
    private fun quickNote(lead: Lead) {
        val input=EditText(this).apply { hint="Add a note"; minLines=3 }
        AlertDialog.Builder(this).setTitle("Timestamped note").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ ->
            val n=input.text.toString().trim()
            if(n.isNotBlank()){ lead.notes += (if(lead.notes.isBlank()) "" else "\n\n")+"["+java.text.DateFormat.getDateTimeInstance().format(java.util.Date())+"] $n"; persist(); renderList() }
        }.show()
    }
    private fun persist() { getSharedPreferences(STORE,0).edit().putString(DATA,JSONArray().also { a -> leads.forEach { l -> a.put(JSONObject().apply { put("id",l.id);put("name",l.name);put("phone",l.phone);put("kind",l.kind);put("area",l.area);put("budget",l.budget);put("need",l.need);put("status",l.status);put("reminder",l.reminder);put("notes",l.notes);put("favorite",l.favorite) }) } }.toString()).apply() }
    private fun load() { try { val a=JSONArray(getSharedPreferences(STORE,0).getString(DATA,"[]")); for(i in 0 until a.length()){val o=a.getJSONObject(i);leads.add(Lead(o.optLong("id"),o.optString("name"),o.optString("phone"),o.optString("kind","Buyer"),o.optString("area"),o.optString("budget"),o.optString("need","Plot"),o.optString("status","New lead"),o.optString("reminder"),o.optString("notes"),o.optBoolean("favorite")))} } catch (_:Exception) {} }
    private fun exportBackup() {
        val json=getSharedPreferences(STORE,0).getString(DATA,"[]") ?: "[]"
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"mydialer-backup.json")
        backupData=json; startActivityForResult(i,300)
    }
    private var backupData="[]"
    @Deprecated("Deprecated Android result API retained for broad compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==300&&resultCode==RESULT_OK&&data?.data!=null){ try { contentResolver.openOutputStream(data.data!!)?.use{it.write(backupData.toByteArray())}; Toast.makeText(this,"Backup saved",Toast.LENGTH_SHORT).show() } catch(e:Exception){Toast.makeText(this,"Backup failed",Toast.LENGTH_SHORT).show()} } }
}
private class SimpleWatcher(val changed:()->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int) {}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) { changed() }
    override fun afterTextChanged(s:android.text.Editable?) {}
}
