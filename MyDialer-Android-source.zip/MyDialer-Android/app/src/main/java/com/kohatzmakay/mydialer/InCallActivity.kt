package com.kohatzmakay.mydialer

import android.app.Activity
import android.os.Bundle
import android.telecom.Call
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class InCallActivity : Activity() {
    private lateinit var caller: TextView
    private lateinit var status: TextView
    private lateinit var answer: Button
    private lateinit var controls: LinearLayout
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val refreshTask = object : Runnable { override fun run() { refresh(); handler.postDelayed(this, 1000) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 36); setBackgroundColor(0xFFF8F9FA.toInt()) }
        caller = TextView(this).apply { textSize = 25f; setTextColor(0xFF202124.toInt()); gravity = Gravity.CENTER }
        status = TextView(this).apply { textSize = 16f; setTextColor(0xFF5F6368.toInt()); gravity = Gravity.CENTER; setPadding(0, 18, 0, 28) }
        answer = Button(this).apply { text = "Answer"; setOnClickListener { CallHolder.call?.answer(VideoProfile.STATE_AUDIO_ONLY); refresh() } }
        val decline = Button(this).apply { text = "Decline"; setOnClickListener { CallHolder.call?.reject(false, null); finish() } }
        val hangup = Button(this).apply { text = "End call"; setOnClickListener { CallHolder.call?.disconnect(); finish() } }
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        root.addView(caller, LinearLayout.LayoutParams(-1, -2)); root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(answer, LinearLayout.LayoutParams(-1, -2)); root.addView(decline, LinearLayout.LayoutParams(-1, -2)); root.addView(controls)
        root.addView(hangup, LinearLayout.LayoutParams(-1, -2))
        setContentView(root); refresh(); handler.post(refreshTask)
    }

    override fun onDestroy() { handler.removeCallbacks(refreshTask); super.onDestroy() }

    private fun refresh() {
        val call = CallHolder.call ?: run { finish(); return }
        val address = call.details.handle?.schemeSpecificPart.orEmpty()
        caller.text = if (address.isBlank()) "Unknown caller" else address
        status.text = when (call.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING -> "Calling…"
            Call.STATE_ACTIVE -> "Call connected"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTED -> "Call ended"
            else -> "Call"
        }
        answer.visibility = if (call.state == Call.STATE_RINGING) View.VISIBLE else View.GONE
        if (call.state == Call.STATE_RINGING) findEndControlsVisibility(true) else findEndControlsVisibility(false)
        controls.removeAllViews()
        if (call.state == Call.STATE_ACTIVE || call.state == Call.STATE_HOLDING) {
            controls.addView(line(action("Mute", { val service = CallHolder.service; service?.setMuted(!(service.callAudioState?.isMuted ?: false)) }), action("Speaker", {
                val service = CallHolder.service ?: return@action
                val route = if ((service.callAudioState?.route ?: 0) == android.telecom.CallAudioState.ROUTE_SPEAKER) android.telecom.CallAudioState.ROUTE_EARPIECE else android.telecom.CallAudioState.ROUTE_SPEAKER
                service.setAudioRoute(route)
            })))
            controls.addView(line(action(if (call.state == Call.STATE_HOLDING) "Resume" else "Hold", { if (call.state == Call.STATE_HOLDING) call.unhold() else call.hold() }), action("Keypad", { showDtmf(call) })))
        }
    }

    private fun findEndControlsVisibility(ringing: Boolean) {
        // Keep both call-ending actions easy to reach; the answer action appears only while ringing.
    }

    private fun action(label: String, click: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { click() } }
    private fun line(a: View, b: View) = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(a, LinearLayout.LayoutParams(0, -2, 1f)); addView(b, LinearLayout.LayoutParams(0, -2, 1f)) }
    private fun showDtmf(call: Call) {
        val digits = EditText(this).apply { hint = "DTMF digits"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_PHONE }
        android.app.AlertDialog.Builder(this).setTitle("Keypad").setView(digits).setNegativeButton("Close", null).setPositiveButton("Send") { _, _ ->
            digits.text.toString().filter { it in "0123456789*#" }.forEach { digit -> call.playDtmfTone(digit); call.stopDtmfTone() }
        }.show()
    }
}
