package com.kohatzmakay.mydialer

import android.app.Activity
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class InCallActivity : Activity() {
    private lateinit var caller: TextView
    private lateinit var status: TextView
    private lateinit var answer: Button
    private lateinit var decline: Button
    private lateinit var hangup: Button
    private lateinit var controls: LinearLayout
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val refreshTask = object : Runnable { override fun run() { refresh(); handler.postDelayed(this, 1000) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 36); setBackgroundColor(0xFFF8F9FA.toInt()) }
        caller = TextView(this).apply { textSize = 25f; setTextColor(0xFF202124.toInt()); gravity = Gravity.CENTER }
        status = TextView(this).apply { textSize = 16f; setTextColor(0xFF5F6368.toInt()); gravity = Gravity.CENTER; setPadding(0, 18, 0, 28) }
        answer = Button(this).apply { text = "Answer"; setOnClickListener { CallHolder.call?.answer(VideoProfile.STATE_AUDIO_ONLY); refresh() } }
        decline = Button(this).apply { text = "Decline"; setOnClickListener { CallHolder.call?.reject(false, null); finish() } }
        hangup = Button(this).apply { text = "End call"; setOnClickListener { CallHolder.call?.disconnect(); finish() } }
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        root.addView(caller, LinearLayout.LayoutParams(-1, -2)); root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(answer, LinearLayout.LayoutParams(-1, -2)); root.addView(decline, LinearLayout.LayoutParams(-1, -2)); root.addView(controls)
        root.addView(hangup, LinearLayout.LayoutParams(-1, -2))
        setContentView(root); refresh(); handler.post(refreshTask)
    }

    override fun onDestroy() { handler.removeCallbacks(refreshTask); super.onDestroy() }

    private fun refresh() {
        val call = CallHolder.call ?: run { finish(); return }
        val address = call.details.handle?.schemeSpecificPart.orEmpty()
        val phone = PhoneSearch.normalize(address)
        caller.text = displayName(address).ifBlank { if (address.isBlank()) "Unknown caller" else address }
        val callState = when (call.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING -> "Calling…"
            Call.STATE_ACTIVE -> "Call connected"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTED -> "Call ended"
            else -> "Call"
        }
        val crm = runCatching { CrmDatabase(this).use { it.profile(phone) } }.getOrNull()
        val summary = crm?.let { listOf(it.category, it.status, it.headline).filter(String::isNotBlank).joinToString(" · ") }.orEmpty()
        status.text = if (summary.isBlank()) callState else "$callState\n$summary"
        answer.visibility = if (call.state == Call.STATE_RINGING) View.VISIBLE else View.GONE
        decline.visibility = if (call.state == Call.STATE_RINGING) View.VISIBLE else View.GONE
        hangup.visibility = if (call.state == Call.STATE_RINGING || call.state == Call.STATE_DISCONNECTED) View.GONE else View.VISIBLE
        controls.removeAllViews()
        if (call.state == Call.STATE_ACTIVE || call.state == Call.STATE_HOLDING) {
            val audioState = CallHolder.service?.callAudioState
            val routeName = when (audioState?.route) {
                android.telecom.CallAudioState.ROUTE_SPEAKER -> "Speaker"
                android.telecom.CallAudioState.ROUTE_BLUETOOTH -> "Bluetooth"
                android.telecom.CallAudioState.ROUTE_WIRED_HEADSET -> "Headset"
                else -> "Earpiece"
            }
            controls.addView(line(action("Mute", { val service = CallHolder.service; service?.setMuted(!(service.callAudioState?.isMuted ?: false)) }), action("Audio: $routeName", {
                val service = CallHolder.service ?: return@action
                val state = service.callAudioState ?: return@action
                val routes = listOf(android.telecom.CallAudioState.ROUTE_EARPIECE, android.telecom.CallAudioState.ROUTE_WIRED_HEADSET, android.telecom.CallAudioState.ROUTE_BLUETOOTH, android.telecom.CallAudioState.ROUTE_SPEAKER)
                    .filter { state.supportedRouteMask and it != 0 }
                if (routes.size > 1) service.setAudioRoute(routes[(routes.indexOf(state.route).coerceAtLeast(0) + 1) % routes.size])
            })))
            val callActions = LinearLayout(this).apply { gravity = Gravity.CENTER }
            if (call.details.can(Call.Details.CAPABILITY_SUPPORT_HOLD)) callActions.addView(action(if (call.state == Call.STATE_HOLDING) "Resume" else "Hold", { if (call.state == Call.STATE_HOLDING) call.unhold() else call.hold() }), LinearLayout.LayoutParams(0, -2, 1f))
            callActions.addView(action("Keypad", { showDtmf(call) }), LinearLayout.LayoutParams(0, -2, 1f))
            if (callActions.childCount > 0) controls.addView(callActions)
            controls.addView(line(action("CRM", { openCrm(phone, false) }), action("Add note", { openCrm(phone, true) })))
        }
    }

    private fun action(label: String, click: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { click() } }
    private fun line(a: View, b: View) = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(a, LinearLayout.LayoutParams(0, -2, 1f)); addView(b, LinearLayout.LayoutParams(0, -2, 1f)) }
    private fun showDtmf(call: Call) {
        val digits = EditText(this).apply { hint = "DTMF digits"; setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_PHONE }
        android.app.AlertDialog.Builder(this).setTitle("Keypad").setView(digits).setNegativeButton("Close", null).setPositiveButton("Send") { _, _ ->
            val sequence = digits.text.toString().filter { it in "0123456789*#" }
            fun play(index: Int) {
                if (index >= sequence.length) return
                call.playDtmfTone(sequence[index])
                handler.postDelayed({
                    call.stopDtmfTone()
                    handler.postDelayed({ play(index + 1) }, 80)
                }, 150)
            }
            play(0)
        }.show()
    }

    private fun openCrm(phone: String, addNote: Boolean) {
        if (phone.isBlank()) return
        startActivity(android.content.Intent(this, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_PROFILE_PHONE, phone)
            .putExtra(MainActivity.EXTRA_ADD_NOTE, addNote)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    private fun displayName(number: String): String {
        if (number.isBlank() || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        return runCatching { contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        } ?: "" }.getOrDefault("")
    }
}
