package com.kohatzmakay.mydialer

import android.app.Activity
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class InCallActivity : Activity() {
    private lateinit var caller: TextView
    private lateinit var status: TextView
    private lateinit var answer: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(28,36,28,36); setBackgroundColor(0xFF10233F.toInt()) }
        caller = TextView(this).apply { textSize=25f; setTextColor(-1); gravity=Gravity.CENTER }
        status = TextView(this).apply { textSize=16f; setTextColor(0xFFD8AD58.toInt()); gravity=Gravity.CENTER; setPadding(0,18,0,28) }
        answer = Button(this).apply { text="Answer"; setOnClickListener { CallHolder.call?.answer(0); refresh() } }
        val end = Button(this).apply { text="End / Decline"; setOnClickListener { CallHolder.call?.disconnect(); finish() } }
        root.addView(caller, LinearLayout.LayoutParams(-1,-2)); root.addView(status, LinearLayout.LayoutParams(-1,-2))
        root.addView(answer, LinearLayout.LayoutParams(-1,-2)); root.addView(end, LinearLayout.LayoutParams(-1,-2))
        setContentView(root); refresh()
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        val c=CallHolder.call ?: run { finish(); return }
        caller.text=c.details.handle?.schemeSpecificPart ?: "Unknown caller"
        status.text=when(c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING -> "Calling…"
            Call.STATE_ACTIVE -> "Call connected"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTED -> "Call ended"
            else -> "Call"
        }
        answer.visibility=if(c.state==Call.STATE_RINGING) View.VISIBLE else View.GONE
    }
}
