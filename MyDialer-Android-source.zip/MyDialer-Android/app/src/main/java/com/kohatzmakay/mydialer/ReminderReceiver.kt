package com.kohatzmakay.mydialer

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            CrmDatabase(context).use { db -> db.tasks().filter { it.dueAt > System.currentTimeMillis() }.forEach { schedule(context, it) } }
            return
        }
        val id = intent.getLongExtra(EXTRA_ID, -1L)
        if (id < 0) return
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "CRM follow-up"
        val phone = intent.getStringExtra(EXTRA_PHONE).orEmpty()
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Follow-up reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(context, id.toInt(), Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_PROFILE_PHONE, phone).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = android.app.Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_call).setContentTitle(title).setContentText("Tap to open MyDialer follow-up")
            .setContentIntent(open).setAutoCancel(true).build()
        runCatching { manager.notify(id.toInt(), notification) }
    }

    companion object {
        const val EXTRA_ID = "task_id"
        const val EXTRA_TITLE = "task_title"
        const val EXTRA_PHONE = "task_phone"
        private const val CHANNEL = "crm_followups"

        fun schedule(context: Context, task: CrmTask) {
            val phone = CrmDatabase(context).use { it.taskPhone(task.id) }
            val intent = Intent(context, ReminderReceiver::class.java).putExtra(EXTRA_ID, task.id).putExtra(EXTRA_TITLE, task.title).putExtra(EXTRA_PHONE, phone)
            val pending = PendingIntent.getBroadcast(context, task.id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.dueAt, pending)
        }

        fun cancel(context: Context, taskId: Long) {
            val pending = PendingIntent.getBroadcast(context, taskId.toInt(), Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
            context.getSystemService(AlarmManager::class.java).cancel(pending)
            pending.cancel()
        }
    }
}
