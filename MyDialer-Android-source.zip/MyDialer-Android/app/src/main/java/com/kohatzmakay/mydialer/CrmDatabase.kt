package com.kohatzmakay.mydialer

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class CrmProfile(
    val phone: String,
    val name: String,
    val category: String,
    val status: String,
    val priority: Int,
    val headline: String,
    val company: String,
    val tags: String = "",
    val customFields: Map<String, String> = emptyMap()
)
data class CrmFieldDefinition(val name: String, val visible: Boolean = true)

data class CrmNote(val id: Long, val phone: String, val body: String, val createdAt: Long, val pinned: Boolean = false)
data class CrmTask(val id: Long, val title: String, val dueAt: Long, val complete: Boolean)
data class CrmInteraction(val id: String, val phone: String, val direction: String, val occurredAt: Long, val duration: Long, val outcome: String)
data class BackupImportResult(val imported: Boolean, val tasksToSchedule: List<CrmTask>)

class CrmDatabase(context: Context) : SQLiteOpenHelper(context, "mydialer-crm.db", null, 8) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE profiles(phone TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Personal', status TEXT NOT NULL DEFAULT 'New', priority INTEGER NOT NULL DEFAULT 0, headline TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX notes_phone_time ON notes(phone, pinned DESC, created_at DESC)")
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, title TEXT NOT NULL, due_at INTEGER NOT NULL, complete INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX tasks_due ON tasks(complete, due_at)")
        db.execSQL("CREATE TABLE interactions(id TEXT PRIMARY KEY, phone TEXT NOT NULL, direction TEXT NOT NULL, occurred_at INTEGER NOT NULL, duration INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE INDEX interactions_phone_time ON interactions(phone, occurred_at DESC)")
        db.execSQL("CREATE TABLE imported_backups(backup_id TEXT PRIMARY KEY, imported_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE crm_options(name TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("CREATE TABLE status_colors(status TEXT PRIMARY KEY, color TEXT NOT NULL)")
        db.execSQL("CREATE TABLE crm_field_definitions(name TEXT PRIMARY KEY, visible INTEGER NOT NULL DEFAULT 1, display_order INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE profile_custom_fields(phone TEXT NOT NULL, field_name TEXT NOT NULL, value TEXT NOT NULL DEFAULT '', PRIMARY KEY(phone,field_name))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE profiles ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE interactions(id TEXT PRIMARY KEY, phone TEXT NOT NULL, direction TEXT NOT NULL, occurred_at INTEGER NOT NULL, duration INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT '')")
            db.execSQL("CREATE INDEX interactions_phone_time ON interactions(phone, occurred_at DESC)")
        }
        if (oldVersion < 4) db.execSQL("CREATE TABLE imported_backups(backup_id TEXT PRIMARY KEY, imported_at INTEGER NOT NULL)")
        if (oldVersion < 5) db.execSQL("CREATE TABLE crm_options(name TEXT PRIMARY KEY, value TEXT NOT NULL)")
        if (oldVersion < 6) db.execSQL("CREATE TABLE status_colors(status TEXT PRIMARY KEY, color TEXT NOT NULL)")
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE notes ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0")
            db.execSQL("DROP INDEX IF EXISTS notes_phone_time")
            db.execSQL("CREATE INDEX notes_phone_time ON notes(phone, pinned DESC, created_at DESC)")
        }
        if (oldVersion < 8) {
            db.execSQL("CREATE TABLE crm_field_definitions(name TEXT PRIMARY KEY, visible INTEGER NOT NULL DEFAULT 1, display_order INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE profile_custom_fields(phone TEXT NOT NULL, field_name TEXT NOT NULL, value TEXT NOT NULL DEFAULT '', PRIMARY KEY(phone,field_name))")
        }
    }

    fun fieldDefinitions(): List<CrmFieldDefinition> = readableDatabase.rawQuery(
        "SELECT name,visible FROM crm_field_definitions ORDER BY display_order,name COLLATE NOCASE", null
    ).use { c -> buildList { while (c.moveToNext()) add(CrmFieldDefinition(c.getString(0), c.getInt(1) != 0)) } }

    fun setFieldDefinitions(definitions: List<CrmFieldDefinition>) {
        val cleaned = definitions.map { CrmFieldDefinition(it.name.trim(), it.visible) }
            .filter { it.name.isNotEmpty() }.distinctBy { it.name.lowercase() }
        require(cleaned.size <= 30 && cleaned.all { it.name.length <= 80 }) { "Use up to 30 custom fields, each up to 80 characters" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val keep = cleaned.mapTo(mutableSetOf()) { it.name }
            db.rawQuery("SELECT name FROM crm_field_definitions", null).use { c ->
                while (c.moveToNext()) {
                    val oldName = c.getString(0)
                    if (oldName !in keep) db.delete("profile_custom_fields", "field_name=?", arrayOf(oldName))
                }
            }
            db.delete("crm_field_definitions", null, null)
            cleaned.forEachIndexed { index, definition ->
                db.insert("crm_field_definitions", null, ContentValues().apply {
                    put("name", definition.name); put("visible", if (definition.visible) 1 else 0); put("display_order", index)
                })
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun customFields(phone: String): Map<String, String> = readableDatabase.rawQuery(
        "SELECT field_name,value FROM profile_custom_fields WHERE phone=? ORDER BY field_name COLLATE NOCASE", arrayOf(phone)
    ).use { c -> buildMap { while (c.moveToNext()) put(c.getString(0), c.getString(1)) } }

    fun optionList(name: String): List<String> {
        require(name in OPTION_DEFAULTS) { "Unsupported CRM option list" }
        val stored = readableDatabase.rawQuery("SELECT value FROM crm_options WHERE name=?", arrayOf(name)).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
        if (stored == null) return OPTION_DEFAULTS.getValue(name)
        return runCatching {
            val array = org.json.JSONArray(stored)
            buildList { for (i in 0 until array.length()) add(array.getString(i)) }
        }.getOrDefault(OPTION_DEFAULTS.getValue(name))
    }

    fun setOptionList(name: String, values: List<String>) {
        require(name in OPTION_DEFAULTS) { "Unsupported CRM option list" }
        val cleaned = values.map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
        require(cleaned.size <= 100 && cleaned.all { it.length <= 80 }) { "Use up to 100 options, each up to 80 characters" }
        writableDatabase.insertWithOnConflict("crm_options", null, ContentValues().apply {
            put("name", name); put("value", org.json.JSONArray(cleaned).toString())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun statusColors(): Map<String, String> {
        val colors = DEFAULT_STATUS_COLORS.toMutableMap()
        readableDatabase.rawQuery("SELECT status,color FROM status_colors", null).use { c ->
            while (c.moveToNext()) if (c.getString(1) in STATUS_COLOR_PALETTE) colors[c.getString(0)] = c.getString(1)
        }
        return colors
    }

    fun setStatusColors(colors: Map<String, String>) {
        require(colors.size <= 100 && colors.all { (status, color) -> status.isNotBlank() && status.length <= 80 && color in STATUS_COLOR_PALETTE }) {
            "Choose a supported color for each status"
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("status_colors", null, null)
            colors.forEach { (status, color) -> db.insert("status_colors", null, ContentValues().apply { put("status", status); put("color", color) }) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun profile(phone: String): CrmProfile? {
        val profile = readableDatabase.rawQuery(
            "SELECT phone,name,category,status,priority,headline,company,tags FROM profiles WHERE phone=?", arrayOf(phone)
        ).use { c -> if (!c.moveToFirst()) null else CrmProfile(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5), c.getString(6), c.getString(7)) }
        return profile?.copy(customFields = customFields(phone))
    }

    fun profiles(): List<CrmProfile> {
        val profiles = readableDatabase.rawQuery(
            "SELECT phone,name,category,status,priority,headline,company,tags FROM profiles ORDER BY priority DESC, name COLLATE NOCASE", null
        ).use { c -> buildList { while (c.moveToNext()) add(CrmProfile(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5), c.getString(6), c.getString(7))) } }
        val allFields = readableDatabase.rawQuery("SELECT phone,field_name,value FROM profile_custom_fields", null).use { c ->
            buildMap<String, MutableMap<String, String>> {
                while (c.moveToNext()) getOrPut(c.getString(0)) { mutableMapOf() }[c.getString(1)] = c.getString(2)
            }
        }
        return profiles.map { it.copy(customFields = allFields[it.phone].orEmpty()) }
    }

    fun saveProfile(p: CrmProfile) {
        require(p.customFields.size <= 30 && p.customFields.all { (name, value) -> name.isNotBlank() && name.length <= 80 && value.length <= 2_000 }) {
            "Use up to 30 custom profile values, each with a field name up to 80 characters and value up to 2,000 characters"
        }
        val values = ContentValues().apply {
            put("phone", p.phone); put("name", p.name); put("category", p.category); put("status", p.status)
            put("priority", p.priority); put("headline", p.headline); put("company", p.company); put("tags", p.tags); put("updated_at", System.currentTimeMillis())
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict("profiles", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            db.delete("profile_custom_fields", "phone=?", arrayOf(p.phone))
            p.customFields.forEach { (name, value) ->
                db.insert("profile_custom_fields", null, ContentValues().apply { put("phone", p.phone); put("field_name", name); put("value", value) })
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addNote(phone: String, body: String): Long = writableDatabase.insert("notes", null, ContentValues().apply {
        put("phone", phone); put("body", body); put("created_at", System.currentTimeMillis())
    })

    fun notes(phone: String): List<CrmNote> = readableDatabase.rawQuery(
        "SELECT id,phone,body,created_at,pinned FROM notes WHERE phone=? ORDER BY pinned DESC,created_at DESC", arrayOf(phone)
    ).use { c -> buildList { while (c.moveToNext()) add(CrmNote(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4) != 0)) } }

    fun searchNotes(term: String): List<CrmNote> {
        val query = term.trim()
        if (query.isEmpty()) return emptyList()
        return readableDatabase.rawQuery(
            "SELECT id,phone,body,created_at,pinned FROM notes WHERE instr(lower(body),lower(?))>0 ORDER BY pinned DESC,created_at DESC LIMIT 100",
            arrayOf(query)
        ).use { c -> buildList { while (c.moveToNext()) add(CrmNote(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4) != 0)) } }
    }

    fun setNotePinned(id: Long, pinned: Boolean) {
        writableDatabase.update("notes", ContentValues().apply { put("pinned", if (pinned) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }

    fun updateNote(id: Long, body: String) {
        writableDatabase.update("notes", ContentValues().apply { put("body", body) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteNote(id: Long) { writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) }

    fun addTask(phone: String, title: String, dueAt: Long): Long = writableDatabase.insert("tasks", null, ContentValues().apply {
        put("phone", phone); put("title", title); put("due_at", dueAt); put("complete", 0)
    })

    fun tasks(includeCompleted: Boolean = false): List<CrmTask> = readableDatabase.rawQuery(
        "SELECT id,title,due_at,complete FROM tasks ${if (includeCompleted) "" else "WHERE complete=0"} ORDER BY due_at", null
    ).use { c -> buildList { while (c.moveToNext()) add(CrmTask(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3) != 0)) } }

    fun setTaskComplete(id: Long, complete: Boolean) {
        writableDatabase.update("tasks", ContentValues().apply { put("complete", if (complete) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }

    fun updateTaskDue(id: Long, dueAt: Long) {
        writableDatabase.update("tasks", ContentValues().apply { put("due_at", dueAt) }, "id=?", arrayOf(id.toString()))
    }

    fun taskPhone(id: Long): String = readableDatabase.rawQuery("SELECT phone FROM tasks WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getString(0) else "" }

    fun logCall(id: String, phone: String, direction: String, occurredAt: Long, duration: Long): Boolean = writableDatabase.insertWithOnConflict("interactions", null, ContentValues().apply {
        put("id", id); put("phone", phone); put("direction", direction); put("occurred_at", occurredAt); put("duration", duration.coerceAtLeast(0))
    }, SQLiteDatabase.CONFLICT_IGNORE) != -1L

    fun interactions(phone: String): List<CrmInteraction> = readableDatabase.rawQuery(
        "SELECT id,phone,direction,occurred_at,duration,outcome FROM interactions WHERE phone=? ORDER BY occurred_at DESC", arrayOf(phone)
    ).use { c -> buildList { while (c.moveToNext()) add(CrmInteraction(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5))) } }

    fun interaction(id: String): CrmInteraction? = readableDatabase.rawQuery(
        "SELECT id,phone,direction,occurred_at,duration,outcome FROM interactions WHERE id=?", arrayOf(id)
    ).use { c -> if (!c.moveToFirst()) null else CrmInteraction(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5)) }

    fun setInteractionOutcome(id: String, outcome: String) {
        writableDatabase.update("interactions", ContentValues().apply { put("outcome", outcome) }, "id=?", arrayOf(id))
    }

    fun importBackup(source: String): BackupImportResult {
        require(source.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "Backup file is larger than 5 MB" }
        val root = org.json.JSONObject(source)
        require(root.optString("format") == BACKUP_FORMAT && root.optInt("version") == 1) { "This is not a supported MyDialer CRM backup" }
        val backupId = root.optString("backupId")
        require(backupId.isNotBlank() && backupId.length <= 100) { "Backup identifier is missing" }
        val profiles = parseArray(root, "profiles", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone"))
            require(phone.isNotBlank() && phone.length <= 64) { "Invalid profile phone number" }
            val fields = item.optJSONObject("customFields")?.let { objectValue ->
                require(objectValue.length() <= 30) { "Too many custom profile fields" }
                buildMap { val keys = objectValue.keys(); while (keys.hasNext()) { val key = keys.next(); put(key, safe(objectValue, key, 2_000)) } }
            }.orEmpty()
            CrmProfile(phone, safe(item, "name", 200), safe(item, "category", 200).ifBlank { "Personal" }, safe(item, "status", 200).ifBlank { "New" }, item.optInt("priority").coerceIn(0, 10), safe(item, "headline", 500), safe(item, "company", 300), safe(item, "tags", 1000), fields)
        }
        val notes = parseArray(root, "notes", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone")); val body = safe(item, "body", 20_000)
            val createdAt = item.optLong("createdAt")
            require(phone.isNotBlank() && body.isNotBlank() && createdAt > 0L) { "Invalid note in backup" }
            ImportedNote(phone, body, createdAt, item.optBoolean("pinned"))
        }
        val tasks = parseArray(root, "tasks", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone")); val title = safe(item, "title", 500); val dueAt = item.optLong("dueAt")
            require(phone.isNotBlank() && title.isNotBlank() && dueAt > 0L) { "Invalid follow-up task in backup" }
            ImportedTask(phone, title, dueAt, item.optBoolean("complete"))
        }
        val interactions = parseArray(root, "interactions", MAX_ROWS) { item ->
            val id = safe(item, "id", 200); val phone = PhoneSearch.normalize(item.optString("phone")); val direction = safe(item, "direction", 50)
            val occurredAt = item.optLong("occurredAt")
            require(id.isNotBlank() && phone.isNotBlank() && direction.isNotBlank() && occurredAt > 0L) { "Invalid call interaction in backup" }
            CrmInteraction(id, phone, direction, occurredAt, item.optLong("duration").coerceAtLeast(0L), safe(item, "outcome", 200))
        }
        val optionLists = OPTION_DEFAULTS.keys.mapNotNull { name ->
            val array = root.optJSONArray(name) ?: return@mapNotNull null
            require(array.length() <= 100) { "Too many $name entries in backup" }
            name to buildList {
                for (i in 0 until array.length()) {
                    val value = array.optString(i).trim()
                    require(value.isNotEmpty() && value.length <= 80) { "Invalid $name entry in backup" }
                    add(value)
                }
            }.distinctBy { it.lowercase() }
        }
        val importedStatusColors = root.optJSONObject("statusColors")?.let { colors ->
            require(colors.length() <= 100) { "Too many status colors in backup" }
            buildMap {
                val keys = colors.keys()
                while (keys.hasNext()) {
                    val status = keys.next()
                    val color = safe(colors, status, 32)
                    require(status.isNotBlank() && status.length <= 80 && color in STATUS_COLOR_PALETTE) { "Invalid status color in backup" }
                    put(status, color)
                }
            }
        }
        val importedFieldDefinitions = root.optJSONArray("customFieldDefinitions")?.let { array ->
            require(array.length() <= 30) { "Too many custom profile fields" }
            buildList { for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: error("Invalid custom profile field")
                val name = safe(item, "name", 80).trim()
                require(name.isNotBlank()) { "Custom profile field name is missing" }
                add(CrmFieldDefinition(name, item.optBoolean("visible", true)))
            } }.distinctBy { it.name.lowercase() }
        }

        val db = writableDatabase
        db.beginTransaction()
        try {
            val existing = db.rawQuery("SELECT 1 FROM imported_backups WHERE backup_id=?", arrayOf(backupId)).use { it.moveToFirst() }
            if (existing) return BackupImportResult(false, emptyList())
            profiles.forEach { p ->
                val values = ContentValues().apply {
                    put("phone", p.phone); put("name", p.name); put("category", p.category); put("status", p.status); put("priority", p.priority)
                    put("headline", p.headline); put("company", p.company); put("tags", p.tags); put("updated_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("profiles", null, values, SQLiteDatabase.CONFLICT_REPLACE)
                p.customFields.forEach { (name, value) -> db.insertWithOnConflict("profile_custom_fields", null, ContentValues().apply {
                    put("phone", p.phone); put("field_name", name); put("value", value)
                }, SQLiteDatabase.CONFLICT_REPLACE) }
            }
            notes.forEach { note -> db.insert("notes", null, ContentValues().apply {
                put("phone", note.phone); put("body", note.body); put("created_at", note.createdAt); put("pinned", if (note.pinned) 1 else 0)
            }) }
            val importedTasks = mutableListOf<CrmTask>()
            tasks.forEach { task ->
                val id = db.insert("tasks", null, ContentValues().apply { put("phone", task.phone); put("title", task.title); put("due_at", task.dueAt); put("complete", if (task.complete) 1 else 0) })
                if (id >= 0 && !task.complete && task.dueAt > System.currentTimeMillis()) importedTasks.add(CrmTask(id, task.title, task.dueAt, false))
            }
            interactions.forEach { event -> db.insertWithOnConflict("interactions", null, ContentValues().apply {
                put("id", event.id); put("phone", event.phone); put("direction", event.direction); put("occurred_at", event.occurredAt); put("duration", event.duration); put("outcome", event.outcome)
            }, SQLiteDatabase.CONFLICT_IGNORE) }
            optionLists.forEach { (name, values) -> db.insertWithOnConflict("crm_options", null, ContentValues().apply {
                put("name", name); put("value", org.json.JSONArray(values).toString())
            }, SQLiteDatabase.CONFLICT_REPLACE) }
            importedStatusColors?.let { colors ->
                db.delete("status_colors", null, null)
                colors.forEach { (status, color) -> db.insert("status_colors", null, ContentValues().apply { put("status", status); put("color", color) }) }
            }
            importedFieldDefinitions?.let { definitions ->
                val keep = definitions.mapTo(mutableSetOf()) { it.name }
                db.rawQuery("SELECT name FROM crm_field_definitions", null).use { c ->
                    while (c.moveToNext()) { val name = c.getString(0); if (name !in keep) db.delete("profile_custom_fields", "field_name=?", arrayOf(name)) }
                }
                db.delete("crm_field_definitions", null, null)
                definitions.forEachIndexed { index, definition -> db.insert("crm_field_definitions", null, ContentValues().apply {
                    put("name", definition.name); put("visible", if (definition.visible) 1 else 0); put("display_order", index)
                }) }
            }
            db.insert("imported_backups", null, ContentValues().apply { put("backup_id", backupId); put("imported_at", System.currentTimeMillis()) })
            db.setTransactionSuccessful()
            return BackupImportResult(true, importedTasks)
        } finally { db.endTransaction() }
    }

    private fun <T> parseArray(root: org.json.JSONObject, key: String, limit: Int, parse: (org.json.JSONObject) -> T): List<T> {
        val array = root.optJSONArray(key) ?: org.json.JSONArray()
        require(array.length() <= limit) { "Too many $key entries in backup" }
        return buildList(array.length()) { for (index in 0 until array.length()) add(parse(array.optJSONObject(index) ?: error("Invalid $key entry"))) }
    }

    private fun safe(item: org.json.JSONObject, key: String, maxLength: Int): String {
        val value = item.optString(key, "")
        require(value.length <= maxLength) { "$key is too long in backup" }
        return value
    }

    private data class ImportedTask(val phone: String, val title: String, val dueAt: Long, val complete: Boolean)
    private data class ImportedNote(val phone: String, val body: String, val createdAt: Long, val pinned: Boolean)

    companion object {
        const val BACKUP_FORMAT = "MyDialer local CRM"
        val OPTION_DEFAULTS = mapOf(
            "categories" to listOf("Personal", "Customer", "Buyer", "Seller", "Business Partner", "Supplier", "Lead", "Other"),
            "statuses" to listOf("New", "Contacted", "Interested", "Follow-up Required", "Waiting for Response", "Meeting Scheduled", "Active", "Completed", "Not Interested", "Archived")
        )
        val STATUS_COLOR_PALETTE = linkedMapOf(
            "Blue" to "#1A73E8", "Green" to "#188038", "Orange" to "#E37400",
            "Red" to "#D93025", "Purple" to "#9334E6", "Gray" to "#5F6368"
        )
        private val DEFAULT_STATUS_COLORS = mapOf(
            "New" to "Blue", "Contacted" to "Gray", "Interested" to "Green", "Follow-up Required" to "Orange",
            "Waiting for Response" to "Purple", "Meeting Scheduled" to "Blue", "Active" to "Green",
            "Completed" to "Gray", "Not Interested" to "Red", "Archived" to "Gray"
        )
        private const val MAX_BACKUP_BYTES = 5 * 1024 * 1024
        private const val MAX_ROWS = 20_000
    }
}
