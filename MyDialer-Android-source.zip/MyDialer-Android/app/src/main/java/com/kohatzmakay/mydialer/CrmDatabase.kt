package com.kohatzmakay.mydialer

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class CrmProfile(
    val phone: String,
    val name: String,
    val category: String,
    val status: String,
    val priority: Int,
    val headline: String,
    val company: String,
    val tags: String = ""
)

data class CrmNote(val id: Long, val phone: String, val body: String, val createdAt: Long)
data class CrmTask(val id: Long, val title: String, val dueAt: Long, val complete: Boolean)
data class CrmInteraction(val id: String, val phone: String, val direction: String, val occurredAt: Long, val duration: Long, val outcome: String)
data class BackupImportResult(val imported: Boolean, val tasksToSchedule: List<CrmTask>)

class CrmDatabase(context: Context) : SQLiteOpenHelper(context, "mydialer-crm.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE profiles(phone TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Personal', status TEXT NOT NULL DEFAULT 'New', priority INTEGER NOT NULL DEFAULT 0, headline TEXT NOT NULL DEFAULT '', company TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX notes_phone_time ON notes(phone, created_at DESC)")
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL, title TEXT NOT NULL, due_at INTEGER NOT NULL, complete INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX tasks_due ON tasks(complete, due_at)")
        db.execSQL("CREATE TABLE interactions(id TEXT PRIMARY KEY, phone TEXT NOT NULL, direction TEXT NOT NULL, occurred_at INTEGER NOT NULL, duration INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE INDEX interactions_phone_time ON interactions(phone, occurred_at DESC)")
        db.execSQL("CREATE TABLE imported_backups(backup_id TEXT PRIMARY KEY, imported_at INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("ALTER TABLE profiles ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE interactions(id TEXT PRIMARY KEY, phone TEXT NOT NULL, direction TEXT NOT NULL, occurred_at INTEGER NOT NULL, duration INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT '')")
            db.execSQL("CREATE INDEX interactions_phone_time ON interactions(phone, occurred_at DESC)")
        }
        if (oldVersion < 4) db.execSQL("CREATE TABLE imported_backups(backup_id TEXT PRIMARY KEY, imported_at INTEGER NOT NULL)")
    }

    fun profile(phone: String): CrmProfile? = readableDatabase.rawQuery(
        "SELECT phone,name,category,status,priority,headline,company,tags FROM profiles WHERE phone=?", arrayOf(phone)
    ).use { c -> if (!c.moveToFirst()) null else CrmProfile(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5), c.getString(6), c.getString(7)) }

    fun profiles(): List<CrmProfile> = readableDatabase.rawQuery(
        "SELECT phone,name,category,status,priority,headline,company,tags FROM profiles ORDER BY priority DESC, name COLLATE NOCASE", null
    ).use { c -> buildList { while (c.moveToNext()) add(CrmProfile(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5), c.getString(6), c.getString(7))) } }

    fun saveProfile(p: CrmProfile) {
        val values = ContentValues().apply {
            put("phone", p.phone); put("name", p.name); put("category", p.category); put("status", p.status)
            put("priority", p.priority); put("headline", p.headline); put("company", p.company); put("tags", p.tags); put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("profiles", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun addNote(phone: String, body: String): Long = writableDatabase.insert("notes", null, ContentValues().apply {
        put("phone", phone); put("body", body); put("created_at", System.currentTimeMillis())
    })

    fun notes(phone: String): List<CrmNote> = readableDatabase.rawQuery(
        "SELECT id,phone,body,created_at FROM notes WHERE phone=? ORDER BY created_at DESC", arrayOf(phone)
    ).use { c -> buildList { while (c.moveToNext()) add(CrmNote(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3))) } }

    fun updateNote(id: Long, body: String) {
        writableDatabase.update("notes", ContentValues().apply { put("body", body) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteNote(id: Long) { writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) }

    fun addTask(phone: String, title: String, dueAt: Long): Long = writableDatabase.insert("tasks", null, ContentValues().apply {
        put("phone", phone); put("title", title); put("due_at", dueAt); put("complete", 0)
    })

    fun tasks(includeCompleted: Boolean = false): List<CrmTask> = readableDatabase.rawQuery(
        "SELECT id,title,due_at,complete FROM tasks ${if (includeCompleted) "" else "WHERE complete=0"} ORDER BY due_at", null
    ).use { c -> buildList { while (c.moveToNext()) add(CrmTask(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3) != 0)) } }

    fun setTaskComplete(id: Long, complete: Boolean) {
        writableDatabase.update("tasks", ContentValues().apply { put("complete", if (complete) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }

    fun updateTaskDue(id: Long, dueAt: Long) {
        writableDatabase.update("tasks", ContentValues().apply { put("due_at", dueAt) }, "id=?", arrayOf(id.toString()))
    }

    fun taskPhone(id: Long): String = readableDatabase.rawQuery("SELECT phone FROM tasks WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getString(0) else "" }

    fun logCall(id: String, phone: String, direction: String, occurredAt: Long, duration: Long): Boolean = writableDatabase.insertWithOnConflict("interactions", null, ContentValues().apply {
        put("id", id); put("phone", phone); put("direction", direction); put("occurred_at", occurredAt); put("duration", duration.coerceAtLeast(0))
    }, SQLiteDatabase.CONFLICT_IGNORE) != -1L

    fun interactions(phone: String): List<CrmInteraction> = readableDatabase.rawQuery(
        "SELECT id,phone,direction,occurred_at,duration,outcome FROM interactions WHERE phone=? ORDER BY occurred_at DESC", arrayOf(phone)
    ).use { c -> buildList { while (c.moveToNext()) add(CrmInteraction(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5))) } }

    fun interaction(id: String): CrmInteraction? = readableDatabase.rawQuery(
        "SELECT id,phone,direction,occurred_at,duration,outcome FROM interactions WHERE id=?", arrayOf(id)
    ).use { c -> if (!c.moveToFirst()) null else CrmInteraction(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5)) }

    fun setInteractionOutcome(id: String, outcome: String) {
        writableDatabase.update("interactions", ContentValues().apply { put("outcome", outcome) }, "id=?", arrayOf(id))
    }

    fun importBackup(source: String): BackupImportResult {
        require(source.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "Backup file is larger than 5 MB" }
        val root = org.json.JSONObject(source)
        require(root.optString("format") == BACKUP_FORMAT && root.optInt("version") == 1) { "This is not a supported MyDialer CRM backup" }
        val backupId = root.optString("backupId")
        require(backupId.isNotBlank() && backupId.length <= 100) { "Backup identifier is missing" }
        val profiles = parseArray(root, "profiles", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone"))
            require(phone.isNotBlank() && phone.length <= 64) { "Invalid profile phone number" }
            CrmProfile(phone, safe(item, "name", 200), safe(item, "category", 200).ifBlank { "Personal" }, safe(item, "status", 200).ifBlank { "New" }, item.optInt("priority").coerceIn(0, 10), safe(item, "headline", 500), safe(item, "company", 300), safe(item, "tags", 1000))
        }
        val notes = parseArray(root, "notes", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone")); val body = safe(item, "body", 20_000)
            val createdAt = item.optLong("createdAt")
            require(phone.isNotBlank() && body.isNotBlank() && createdAt > 0L) { "Invalid note in backup" }
            Triple(phone, body, createdAt)
        }
        val tasks = parseArray(root, "tasks", MAX_ROWS) { item ->
            val phone = PhoneSearch.normalize(item.optString("phone")); val title = safe(item, "title", 500); val dueAt = item.optLong("dueAt")
            require(phone.isNotBlank() && title.isNotBlank() && dueAt > 0L) { "Invalid follow-up task in backup" }
            ImportedTask(phone, title, dueAt, item.optBoolean("complete"))
        }
        val interactions = parseArray(root, "interactions", MAX_ROWS) { item ->
            val id = safe(item, "id", 200); val phone = PhoneSearch.normalize(item.optString("phone")); val direction = safe(item, "direction", 50)
            val occurredAt = item.optLong("occurredAt")
            require(id.isNotBlank() && phone.isNotBlank() && direction.isNotBlank() && occurredAt > 0L) { "Invalid call interaction in backup" }
            CrmInteraction(id, phone, direction, occurredAt, item.optLong("duration").coerceAtLeast(0L), safe(item, "outcome", 200))
        }

        val db = writableDatabase
        db.beginTransaction()
        try {
            val existing = db.rawQuery("SELECT 1 FROM imported_backups WHERE backup_id=?", arrayOf(backupId)).use { it.moveToFirst() }
            if (existing) return BackupImportResult(false, emptyList())
            profiles.forEach { p ->
                val values = ContentValues().apply {
                    put("phone", p.phone); put("name", p.name); put("category", p.category); put("status", p.status); put("priority", p.priority)
                    put("headline", p.headline); put("company", p.company); put("tags", p.tags); put("updated_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("profiles", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            notes.forEach { (phone, body, createdAt) -> db.insert("notes", null, ContentValues().apply { put("phone", phone); put("body", body); put("created_at", createdAt) }) }
            val importedTasks = mutableListOf<CrmTask>()
            tasks.forEach { task ->
                val id = db.insert("tasks", null, ContentValues().apply { put("phone", task.phone); put("title", task.title); put("due_at", task.dueAt); put("complete", if (task.complete) 1 else 0) })
                if (id >= 0 && !task.complete && task.dueAt > System.currentTimeMillis()) importedTasks.add(CrmTask(id, task.title, task.dueAt, false))
            }
            interactions.forEach { event -> db.insertWithOnConflict("interactions", null, ContentValues().apply {
                put("id", event.id); put("phone", event.phone); put("direction", event.direction); put("occurred_at", event.occurredAt); put("duration", event.duration); put("outcome", event.outcome)
            }, SQLiteDatabase.CONFLICT_IGNORE) }
            db.insert("imported_backups", null, ContentValues().apply { put("backup_id", backupId); put("imported_at", System.currentTimeMillis()) })
            db.setTransactionSuccessful()
            return BackupImportResult(true, importedTasks)
        } finally { db.endTransaction() }
    }

    private fun <T> parseArray(root: org.json.JSONObject, key: String, limit: Int, parse: (org.json.JSONObject) -> T): List<T> {
        val array = root.optJSONArray(key) ?: org.json.JSONArray()
        require(array.length() <= limit) { "Too many $key entries in backup" }
        return buildList(array.length()) { for (index in 0 until array.length()) add(parse(array.optJSONObject(index) ?: error("Invalid $key entry"))) }
    }

    private fun safe(item: org.json.JSONObject, key: String, maxLength: Int): String {
        val value = item.optString(key, "")
        require(value.length <= maxLength) { "$key is too long in backup" }
        return value
    }

    private data class ImportedTask(val phone: String, val title: String, val dueAt: Long, val complete: Boolean)

    companion object {
        const val BACKUP_FORMAT = "MyDialer local CRM"
        private const val MAX_BACKUP_BYTES = 5 * 1024 * 1024
        private const val MAX_ROWS = 20_000
    }
}
