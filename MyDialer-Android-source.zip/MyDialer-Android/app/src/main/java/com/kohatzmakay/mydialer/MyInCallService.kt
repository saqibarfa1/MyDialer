package com.kohatzmakay.mydialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService

class MyInCallService : InCallService() {
    override fun onCreate() {
        super.onCreate()
        CallHolder.service = this
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallHolder.call = call
        val intent = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(this, 500, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Phone calls", NotificationManager.IMPORTANCE_HIGH).apply { lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC })
        val number = call.details.handle?.schemeSpecificPart ?: "Unknown number"
        val notification = android.app.Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(number)
            .setContentText(if (call.state == Call.STATE_RINGING) "Incoming call" else "Call in progress")
            .setCategory(android.app.Notification.CATEGORY_CALL).setOngoing(true).setContentIntent(pending)
            .setFullScreenIntent(pending, true).build()
        runCatching { manager.notify(CALL_NOTIFICATION_ID, notification) }
        runCatching { startActivity(intent) }
    }

    override fun onCallRemoved(call: Call) {
        if (CallHolder.call === call) CallHolder.call = null
        getSystemService(NotificationManager::class.java).cancel(CALL_NOTIFICATION_ID)
        super.onCallRemoved(call)
    }

    override fun onDestroy() {
        if (CallHolder.service === this) CallHolder.service = null
        super.onDestroy()
    }

    companion object { private const val CHANNEL = "ongoing_calls"; private const val CALL_NOTIFICATION_ID = 500 }
}

object CallHolder { @Volatile var call: Call? = null; @Volatile var service: InCallService? = null }
