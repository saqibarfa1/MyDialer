package com.kohatzmakay.mydialer

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService

class MyInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallHolder.call = call
        startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
    override fun onCallRemoved(call: Call) {
        if (CallHolder.call === call) CallHolder.call = null
        super.onCallRemoved(call)
    }
}
object CallHolder { @Volatile var call: Call? = null }
