package com.kohatzmakay.mydialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService

class MyInCallService : InCallService() {
    override fun onCreate() {
        super.onCreate()
        CallHolder.service = this
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallHolder.call = call
        val intent = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(this, 500, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Phone calls", NotificationManager.IMPORTANCE_HIGH).apply { lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC })
        val number = call.details.handle?.schemeSpecificPart ?: "Unknown number"
        val notification = android.app.Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.sym_action_call).setContentTitle(number)
            .setContentText(if (call.state == Call.STATE_RINGING) "Incoming call" else "Call in progress")
            .setCategory(android.app.Notification.CATEGORY_CALL).setOngoing(true).setContentIntent(pending)
            .setFullScreenIntent(pending, true).build()
        runCatching { manager.notify(CALL_NOTIFICATION_ID, notification) }
        runCatching { startActivity(intent) }
    }

    override fun onCallRemoved(call: Call) {
        val address = call.details.handle?.schemeSpecificPart.orEmpty()
        val phone = PhoneSearch.normalize(address)
        if (phone.isNotBlank()) {
            val details = call.details
            val connectedAt = details.connectTimeMillis
            val startedAt = if (connectedAt > 0L) connectedAt else details.creationTimeMillis
            val direction = if (Build.VERSION.SDK_INT >= 29) when (details.callDirection) {
                Call.Details.DIRECTION_INCOMING -> "Incoming"
                Call.Details.DIRECTION_OUTGOING -> "Outgoing"
                else -> "Call"
            } else "Call"
            val eventId = "$phone:$startedAt:$direction"
            val now = System.currentTimeMillis()
            val duration = if (connectedAt > 0L) (now - connectedAt) / 1000L else 0L
            val inserted = runCatching { CrmDatabase(this).use { it.logCall(eventId, phone, direction, now, duration) } }.getOrDefault(false)
            if (inserted) showPostCallNotification(phone, eventId, direction)
        }
        if (CallHolder.call === call) CallHolder.call = null
        getSystemService(NotificationManager::class.java).cancel(CALL_NOTIFICATION_ID)
        super.onCallRemoved(call)
    }

    override fun onDestroy() {
        if (CallHolder.service === this) CallHolder.service = null
        super.onDestroy()
    }

    private fun showPostCallNotification(phone: String, eventId: String, direction: String) {
        val intent = Intent(this, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_PROFILE_PHONE, phone)
            .putExtra(MainActivity.EXTRA_POST_CALL_ID, eventId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(this, eventId.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = android.app.Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Log $direction")
            .setContentText("Add an outcome or follow-up to this call")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        runCatching { getSystemService(NotificationManager::class.java).notify(eventId.hashCode(), notification) }
    }

    companion object { private const val CHANNEL = "ongoing_calls"; private const val CALL_NOTIFICATION_ID = 500 }
}

object CallHolder { @Volatile var call: Call? = null; @Volatile var service: InCallService? = null }
