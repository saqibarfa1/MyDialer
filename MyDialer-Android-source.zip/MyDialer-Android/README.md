# MyDialer

MyDialer is a native Kotlin Android app that combines the phone dialer entry point with device contacts and a local CRM. Contact and call-log access is optional and controlled by Android permissions. CRM profiles, notes, and reminders are stored on-device.

## Current implementation

- Five destinations: Favorites, Recents, Contacts, Keypad, and CRM.
- T9 name and phone-number matching over contacts the user has allowed the app to read.
- Device contact queries and call-log access gated by Android's default phone app role, with permission-denied states.
- Recents show call type, timestamp, duration, and phone-account ID when the call-log provider supplies it; a details action and callback are available. The account column is optional, so unsupported providers fall back to the remaining call fields.
- Recents offer individual call-entry deletion and clearing all call history after confirmation. Android's restricted `WRITE_CALL_LOG` permission and the device's installer/policy may prevent these actions; CRM records and contacts are unaffected.
- Unknown numbers can be prefilled into Android's Contacts editor. Contact add/edit is delegated to that system app; calls and messages use supported Android intents.
- Default dialer role request initiated from CRM → Settings.
- Preferred outgoing SIM selection when Android exposes multiple call-capable phone accounts and the user grants phone-state access.
- An `InCallService` and in-call screen using Telecom call answer/reject/disconnect, mute, audio route, hold, and DTMF APIs.
- Local SQLite CRM profiles, editable category/status/headline/company/tags/priority, timestamped searchable and pinnable notes, and follow-up tasks that can be completed, reopened, snoozed by one day, or rescheduled.
- Custom contact-category and status suggestions can be edited in CRM settings; category line order controls suggestions, statuses can be reordered and assigned a color, and these settings are included in CRM backups.
- Custom CRM profile fields can be added, ordered, shown or hidden, edited per profile, searched, and included in CRM backups. Removing a field also removes its saved values.
- Reminder notifications scheduled with inexact allow-while-idle alarms and rescheduled after device reboot.
- In-app call lifecycle interactions are deduplicated in SQLite; users can optionally log a post-call outcome, note, or follow-up from a notification.
- Post-call prompts can be turned on or off in CRM settings; disabling prompts still records the in-app call interaction.
- Light, dark, and system appearance settings, plus validated local CRM JSON export/import and local CRM deletion controls.
- One-time import of profiles, notes, and other CRM text from the prototype's SharedPreferences JSON.

## Build and tests

From this directory, run `gradle testDebugUnitTest assembleDebug`. GitHub Actions runs this same task sequence on pushes to `main`, then publishes the debug APK as a workflow artifact.

## Permissions

- `READ_CONTACTS`: display contacts and enable T9 suggestions.
- `READ_CALL_LOG`: display call history.
- `WRITE_CALL_LOG`: delete or clear call history after a user-initiated action; Android restricts this permission and may not grant it to every installation.
- `CALL_PHONE`: direct calling where granted; otherwise MyDialer opens the system dial screen.
- `READ_PHONE_STATE`: list call-capable phone accounts for an optional outgoing SIM preference.
- `ANSWER_PHONE_CALLS`: support answering calls through Telecom when the app has the default dialer role.
- `POST_NOTIFICATIONS`: show follow-up reminders on Android 13 and newer.
- `RECEIVE_BOOT_COMPLETED`: restore pending follow-up alarms after a reboot.
- `USE_FULL_SCREEN_INTENT`: request supported incoming-call presentation on Android versions that permit it.

## Set as default dialer

Open MyDialer → CRM → Settings → **Set MyDialer as default phone app**, then accept Android's system prompt. Declining keeps the app usable in a limited mode. Device support and Android policy determine which Telecom functions are available.

## Limitations requiring further implementation or device verification

- The current app is an incremental foundation. Contact photos/details beyond names and phone numbers, configurable workflow rules, and cloud sync are not implemented.
- CRM categories, statuses, status colors, and profile fields are configurable. Configurable workflow rules are not implemented.
- Android controls call-log access and call-log modification. Call history is shown only while MyDialer holds the default phone app role. Delete/clear actions request `WRITE_CALL_LOG` only after the user selects the action; Android or the installer may refuse this hard-restricted permission, and the app then leaves the history unchanged.
- Incoming/ongoing call presentation, call audio routes, answer/reject behavior, permissions, reminder delivery, reboot restoration, and default-dialer role need testing on physical devices across Android versions. No real call has been tested by CI.
- Reminder delivery uses inexact alarms. Doze mode and manufacturer battery policies can delay a notification; it is not an exact-time alarm.
- Current interface copy is English. RTL layout support is enabled at the manifest level, but Urdu localization and bidi-specific phone-number QA remain to be done.
- Automated tests cover phone-number normalization, T9 matching, keypad/navigation interaction, default-dialer call-log gating, post-call preference control, call-type labels, contact-insert intents, local CRM CRUD and custom fields, note pinning/search, call-event deduplication, database upgrades, and validated backup import/deduplication. Telecom integration still needs device testing.
