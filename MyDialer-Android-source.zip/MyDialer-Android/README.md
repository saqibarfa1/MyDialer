# MyDialer

MyDialer is a native Kotlin Android app that combines the phone dialer entry point with device contacts and a local CRM. Contact and call-log access is optional and controlled by Android permissions. CRM profiles, notes, and reminders are stored on-device.

## Current implementation

- Five destinations: Favorites, Recents, Contacts, Keypad, and CRM.
- T9 name and phone-number matching over contacts the user has allowed the app to read.
- Device contact and call-log queries, with permission-denied states.
- Contact add/edit delegated to Android's Contacts app; calls and messages delegated to supported Android intents.
- Default dialer role request initiated from CRM → Settings.
- An `InCallService` and in-call screen using Telecom call answer/reject/disconnect, mute, audio route, hold, and DTMF APIs.
- Local SQLite CRM profiles, editable category/status/headline/company/tags/priority, timestamped notes, and follow-up tasks.
- Reminder notifications scheduled with inexact allow-while-idle alarms and rescheduled after device reboot.
- In-app call lifecycle interactions are deduplicated in SQLite; users can optionally log a post-call outcome, note, or follow-up from a notification.
- One-time import of profiles, notes, and other CRM text from the prototype's SharedPreferences JSON.

## Build and tests

From this directory, run `gradle testDebugUnitTest assembleDebug`. GitHub Actions runs this same task sequence on pushes to `main`, then publishes the debug APK as a workflow artifact.

## Permissions

- `READ_CONTACTS`: display contacts and enable T9 suggestions.
- `READ_CALL_LOG`: display call history.
- `CALL_PHONE`: direct calling where granted; otherwise MyDialer opens the system dial screen.
- `ANSWER_PHONE_CALLS`: support answering calls through Telecom when the app has the default dialer role.
- `POST_NOTIFICATIONS`: show follow-up reminders on Android 13 and newer.
- `RECEIVE_BOOT_COMPLETED`: restore pending follow-up alarms after a reboot.
- `USE_FULL_SCREEN_INTENT`: request supported incoming-call presentation on Android versions that permit it.

## Set as default dialer

Open MyDialer → CRM → Settings → **Set MyDialer as default phone app**, then accept Android's system prompt. Declining keeps the app usable in a limited mode. Device support and Android policy determine which Telecom functions are available.

## Limitations requiring further implementation or device verification

- The current app is an incremental foundation, not full Google Phone parity. SIM selection, contact photos/details beyond names and phone numbers, call-history deletion, configurable CRM fields/workflows, cloud sync, and backup import are not implemented.
- Android controls call-log access and call-log modification. This app currently reads supported call-history data but does not clear or edit it.
- Incoming/ongoing call presentation, call audio routes, answer/reject behavior, permissions, reminder delivery, reboot restoration, and default-dialer role need testing on physical devices across Android versions. No real call has been tested by CI.
- Reminder delivery uses inexact alarms. Doze mode and manufacturer battery policies can delay a notification; it is not an exact-time alarm.
- Current interface copy is English. RTL layout support is enabled at the manifest level, but Urdu localization and bidi-specific phone-number QA remain to be done.
- Automated tests currently cover phone-number normalization and T9 matching. Database migrations and Telecom integration still need broader automated and device tests.
