# MyDialer

MyDialer is a native Kotlin Android app that combines the phone dialer entry point with device contacts and a local CRM. Contact and call-log access is optional and controlled by Android permissions. CRM profiles, notes, and reminders are stored on-device.

## Current implementation

- Five destinations: Favorites, Recents, Contacts, Keypad, and CRM.
- T9 name and phone-number matching over contacts the user has allowed the app to read.
- Device contact and call-log queries, with permission-denied states.
- Contact add/edit delegated to Android's Contacts app; calls and messages delegated to supported Android intents.
- Default dialer role request initiated from CRM → Settings.
- Preferred outgoing SIM selection when Android exposes multiple call-capable phone accounts and the user grants phone-state access.
- An `InCallService` and in-call screen using Telecom call answer/reject/disconnect, mute, audio route, hold, and DTMF APIs.
- Local SQLite CRM profiles, editable category/status/headline/company/tags/priority, timestamped notes, and follow-up tasks that can be completed, reopened, snoozed by one day, or rescheduled.
- Custom contact-category and status suggestions can be edited in CRM settings; category line order controls suggestions, statuses can be reordered and assigned a color, and these settings are included in CRM backups.
- Reminder notifications scheduled with inexact allow-while-idle alarms and rescheduled after device reboot.
- In-app call lifecycle interactions are deduplicated in SQLite; users can optionally log a post-call outcome, note, or follow-up from a notification.
- Light, dark, and system appearance settings, plus validated local CRM JSON export/import and local CRM deletion controls.
- One-time import of profiles, notes, and other CRM text from the prototype's SharedPreferences JSON.

## Build and tests

From this directory, run `gradle testDebugUnitTest assembleDebug`. GitHub Actions runs this same task sequence on pushes to `main`, then publishes the debug APK as a workflow artifact.

## Permissions

- `READ_CONTACTS`: display contacts and enable T9 suggestions.
- `READ_CALL_LOG`: display call history.
- `CALL_PHONE`: direct calling where granted; otherwise MyDialer opens the system dial screen.
- `READ_PHONE_STATE`: list call-capable phone accounts for an optional outgoing SIM preference.
- `ANSWER_PHONE_CALLS`: support answering calls through Telecom when the app has the default dialer role.
- `POST_NOTIFICATIONS`: show follow-up reminders on Android 13 and newer.
- `RECEIVE_BOOT_COMPLETED`: restore pending follow-up alarms after a reboot.
- `USE_FULL_SCREEN_INTENT`: request supported incoming-call presentation on Android versions that permit it.

## Set as default dialer

Open MyDialer → CRM → Settings → **Set MyDialer as default phone app**, then accept Android's system prompt. Declining keeps the app usable in a limited mode. Device support and Android policy determine which Telecom functions are available.

## Limitations requiring further implementation or device verification

- The current app is an incremental foundation, not full Google Phone parity. Contact photos/details beyond names and phone numbers, call-history deletion, configurable CRM field visibility/workflows, and cloud sync are not implemented.
- CRM categories, statuses, and status colors are configurable. User-defined CRM fields, profile field visibility, and configurable workflow rules are not implemented.
- Android controls call-log access and call-log modification. This app currently reads supported call-history data but does not clear or edit it.
- Incoming/ongoing call presentation, call audio routes, answer/reject behavior, permissions, reminder delivery, reboot restoration, and default-dialer role need testing on physical devices across Android versions. No real call has been tested by CI.
- Reminder delivery uses inexact alarms. Doze mode and manufacturer battery policies can delay a notification; it is not an exact-time alarm.
- Current interface copy is English. RTL layout support is enabled at the manifest level, but Urdu localization and bidi-specific phone-number QA remain to be done.
- Automated tests cover phone-number normalization, T9 matching, local CRM CRUD, call-event deduplication, database upgrade, and validated backup import/deduplication. Telecom integration still needs device testing.
